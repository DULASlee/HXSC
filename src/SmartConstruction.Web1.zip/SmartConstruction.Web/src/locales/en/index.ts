import dashboard from './dashboard'
import common from './common'
import theme from './theme'

export default {
  dashboard,
  common,
  theme
} 