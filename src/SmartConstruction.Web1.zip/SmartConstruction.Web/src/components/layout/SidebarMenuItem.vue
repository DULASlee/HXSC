<template>
  <div class="sidebar-menu-item">
    <!-- 单级菜单 -->
    <el-menu-item 
      v-if="!menu.children || menu.children.length === 0"
      :index="menu.path || menu.code"
      :class="{ 'is-active': isActive }"
      @click="handleMenuClick(menu)"
    >
      <el-icon v-if="menu.icon">
        <component :is="getIconComponent(menu.icon)" />
      </el-icon>
      <template #title>
        <span>{{ menu.name }}</span>
      </template>
    </el-menu-item>
    
    <!-- 多级菜单 -->
    <el-sub-menu 
      v-else-if="hasVisibleChildren"
      :index="menu.path || menu.code"
      :class="{ 'is-active': hasActiveChild }"
      :popper-append-to-body="false"
    >
      <template #title>
        <el-icon v-if="menu.icon">
          <component :is="getIconComponent(menu.icon)" />
        </el-icon>
        <span>{{ menu.name }}</span>
      </template>
      
      <sidebar-menu-item
        v-for="child in visibleChildren"
        :key="child.id"
        :menu="child"
        :is-collapsed="isCollapsed"
        :active-path="activePath"
      />
    </el-sub-menu>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useRouter } from 'vue-router'

// 组件名称定义
defineOptions({
  name: 'SidebarMenuItem'
})

// 菜单类型定义
interface Menu {
  id: string
  code: string
  name: string
  type: string
  path?: string
  icon?: string
  isVisible: boolean
  isEnabled: boolean
  isExternal?: boolean
  children?: Menu[]
}

interface Props {
  menu: Menu
  isCollapsed: boolean
  activePath?: string
}

const props = withDefaults(defineProps<Props>(), {
  activePath: ''
})

const router = useRouter()

// 图标映射
import { 
  House,
  User,
  Setting,
  Document,
  Folder,
  Files,
  DataAnalysis,
  Monitor,
  Lock,
  Avatar,
  Menu as MenuIcon,
  OfficeBuilding,
  Connection,
  Warning,
  Bell,
  TrendCharts,
  UserFilled,
  Share,
  Postcard
} from '@element-plus/icons-vue'

const iconMap: Record<string, any> = {
  House,
  User,
  Setting,
  Document,
  Folder,
  Files,
  DataAnalysis,
  Monitor,
  Lock,
  Avatar,
  Menu: MenuIcon,
  OfficeBuilding,
  Connection,
  Warning,
  Bell,
  TrendCharts,
  UserFilled,
  Share,
  Postcard,
  HomeFilled: House,
}

/// <summary>
/// 获取图标组件
/// </summary>
const getIconComponent = (iconName: string) => {
  return iconMap[iconName] || Document
}

/// <summary>
/// 可见的子菜单
/// </summary>
const visibleChildren = computed(() => {
  return props.menu.children?.filter(child => child.isVisible && child.isEnabled) || []
})

/// <summary>
/// 是否有可见的子菜单
/// </summary>
const hasVisibleChildren = computed(() => {
  return visibleChildren.value.length > 0
})

/// <summary>
/// 判断当前菜单是否激活
/// </summary>
const isActive = computed(() => {
  return props.activePath === (props.menu.path || props.menu.code)
})

/// <summary>
/// 判断是否有激活的子菜单
/// </summary>
const hasActiveChild = computed(() => {
  if (!props.menu.children) return false
  
  const checkChild = (children: Menu[]): boolean => {
    return children.some(child => {
      const childPath = child.path || child.code
      if (props.activePath === childPath) return true
      if (child.children) return checkChild(child.children)
      return false
    })
  }
  
  return checkChild(props.menu.children)
})

/// <summary>
/// 处理菜单点击事件
/// </summary>
const handleMenuClick = (menu: Menu) => {
  if (!menu.path) return
  
  console.log(`[菜单点击] ${menu.name}: ${menu.path}`)
  
  if (menu.isExternal) {
    // 外部链接在新窗口打开
    window.open(menu.path, '_blank')
  } else {
    // 内部路由跳转
    router.push(menu.path)
  }
}
</script>

<style lang="scss" scoped>
.sidebar-menu-item {
  // 样式由父组件定义
}
</style>