<template>
  <div class="language-switcher">
    <el-dropdown 
      trigger="click" 
      placement="bottom-end"
      @command="handleLanguageChange"
    >
      <el-button 
        :icon="Globe" 
        circle 
        :title="$t('system.language')"
        class="language-button"
      />
      
      <template #dropdown>
        <el-dropdown-menu class="language-dropdown">
          <div class="language-header">
            <el-icon><Globe /></el-icon>
            <span>{{ $t('system.language') }}</span>
          </div>
          
          <div class="language-list">
            <el-dropdown-item
              v-for="lang in languages"
              :key="lang.code"
              :command="lang.code"
              :class="{ 'is-active': currentLanguage === lang.code }"
            >
              <div class="language-item">
                <span class="language-flag">{{ lang.flag }}</span>
                <div class="language-info">
                  <div class="language-name">{{ lang.name }}</div>
                  <div class="language-native">{{ lang.nativeName }}</div>
                </div>
                <el-icon v-if="currentLanguage === lang.code" class="language-check">
                  <Check />
                </el-icon>
              </div>
            </el-dropdown-item>
          </div>
        </el-dropdown-menu>
      </template>
    </el-dropdown>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import { ElMessage } from 'element-plus'
import { Globe, Check } from '@element-plus/icons-vue'
import { useI18nStore } from '@/stores/i18n'
import { useAppStore } from '@/stores/app'

const i18nStore = useI18nStore()
const appStore = useAppStore()

// 当前语言
const currentLanguage = computed(() => i18nStore.locale)

// 支持的语言列表
const languages = ref([
  {
    code: 'zh-CN',
    name: '简体中文',
    nativeName: '中文',
    flag: '🇨🇳'
  },
  {
    code: 'en-US',
    name: 'English',
    nativeName: 'English',
    flag: '🇺🇸'
  },
  {
    code: 'ja-JP',
    name: '日本語',
    nativeName: '日本語',
    flag: '🇯🇵'
  }
])

// 处理语言切换
const handleLanguageChange = (langCode: string) => {
  if (langCode === currentLanguage.value) return
  
  try {
    // 切换语言
    i18nStore.setLocale(langCode as any)
    appStore.setLanguage(langCode as any)
    
    // 更新页面标题和HTML lang属性
    document.documentElement.lang = langCode
    
    // 显示成功消息
    const langName = languages.value.find(lang => lang.code === langCode)?.name || langCode
    ElMessage.success(`语言已切换为 ${langName}`)
    
    // 可以在这里添加更多语言切换后的处理逻辑
    // 比如重新加载某些数据、更新路由等
    
  } catch (error) {
    console.error('语言切换失败:', error)
    ElMessage.error('语言切换失败，请重试')
  }
}

// 获取翻译文本的辅助函数
const $t = computed(() => i18nStore.t)
</script>

<style lang="scss" scoped>
.language-switcher {
  .language-button {
    border: none;
    background: transparent;
    color: var(--navbar-text);
    
    &:hover {
      background: var(--sidebar-hover-bg);
    }
  }
}

.language-dropdown {
  width: 240px;
  padding: 0;
  
  .language-header {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 12px 16px;
    font-weight: 500;
    color: var(--text-primary);
    border-bottom: 1px solid var(--border-color-light);
    background: var(--bg-elevated);
  }
  
  .language-list {
    padding: 8px 0;
  }
  
  .language-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 8px 16px;
    width: 100%;
    
    &:hover {
      background: var(--bg-elevated);
    }
  }
  
  .language-flag {
    font-size: 18px;
    width: 24px;
    text-align: center;
  }
  
  .language-info {
    flex: 1;
    
    .language-name {
      font-weight: 500;
      color: var(--text-primary);
      margin-bottom: 2px;
    }
    
    .language-native {
      font-size: 12px;
      color: var(--text-secondary);
    }
  }
  
  .language-check {
    color: var(--primary-color);
    font-size: 16px;
  }
  
  :deep(.el-dropdown-menu__item) {
    padding: 0;
    
    &.is-active {
      background: var(--primary-bg);
      color: var(--primary-color);
      
      .language-name {
        color: var(--primary-color);
      }
    }
    
    &:hover {
      background: var(--bg-elevated);
    }
  }
}

// 响应式适配
@media (max-width: 768px) {
  .language-dropdown {
    width: 200px;
    
    .language-item {
      padding: 6px 12px;
      gap: 8px;
    }
    
    .language-flag {
      font-size: 16px;
      width: 20px;
    }
    
    .language-info {
      .language-name {
        font-size: 14px;
      }
      
      .language-native {
        font-size: 11px;
      }
    }
  }
}
</style>