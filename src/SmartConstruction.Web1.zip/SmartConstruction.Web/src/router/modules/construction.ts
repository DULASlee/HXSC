// =============================================
// 智慧工地路由配置
// =============================================
import type { RouteRecordRaw } from 'vue-router'

// 动态导入布局组件，避免循环依赖初始化问题
const Layout = () => import('@/layouts/DefaultLayout.vue');

// 智慧工地路由
const constructionRoutes: RouteRecordRaw[] = [
  {
    path: '/tenant',
    component: Layout,
    redirect: '/tenant/list',
    name: 'TenantManagement',
    meta: { title: '租户管理', icon: 'OfficeBuilding', permission: 'tenant.view' },
    children: [
      {
        path: 'list',
        name: 'TenantList',
        component: () => import('@/views/tenant/list/index.vue'),
        meta: { title: '租户列表', icon: 'List', permission: 'tenant.view' }
      },
      {
        path: 'detail/:id',
        name: 'TenantDetail',
        component: () => import('@/views/tenant/detail/index.vue'),
        meta: { title: '租户详情', icon: 'Document', permission: 'tenant.view', hidden: true }
      }
    ]
  },
  {
    path: '/company',
    component: Layout,
    redirect: '/company/list',
    name: 'CompanyManagement',
    meta: { title: '公司管理', icon: 'OfficeBuilding', permission: 'company.view' },
    children: [
      {
        path: 'list',
        name: 'CompanyList',
        component: () => import('@/views/company/list/index.vue'),
        meta: { title: '公司列表', icon: 'List', permission: 'company.view' }
      },
      {
        path: 'detail/:id',
        name: 'CompanyDetail',
        component: () => import('@/views/company/detail/index.vue'),
        meta: { title: '公司详情', icon: 'Document', permission: 'company.view', hidden: true }
      }
    ]
  },
  {
    path: '/project',
    component: Layout,
    redirect: '/project/list',
    name: 'ProjectManagement',
    meta: { title: '项目管理', icon: 'Document', permission: 'project.view' },
    children: [
      {
        path: 'list',
        name: 'ProjectList',
        component: () => import('@/views/project/list/index.vue'),
        meta: { title: '项目列表', icon: 'List', permission: 'project.view' }
      },
      {
        path: 'detail/:id',
        name: 'ProjectDetail',
        component: () => import('@/views/project/detail/index.vue'),
        meta: { title: '项目详情', icon: 'Document', permission: 'project.view', hidden: true }
      }
    ]
  },
  {
    path: '/team',
    component: Layout,
    redirect: '/team/list',
    name: 'TeamManagement',
    meta: { title: '班组管理', icon: 'User', permission: 'team.view' },
    children: [
      {
        path: 'list',
        name: 'TeamList',
        component: () => import('@/views/team/list/index.vue'),
        meta: { title: '班组列表', icon: 'List', permission: 'team.view' }
      },
      {
        path: 'detail/:id',
        name: 'TeamDetail',
        component: () => import('@/views/team/detail/index.vue'),
        meta: { title: '班组详情', icon: 'Document', permission: 'team.view', hidden: true }
      }
    ]
  },
  {
    path: '/worker',
    component: Layout,
    redirect: '/worker/list',
    name: 'WorkerManagement',
    meta: { title: '工人管理', icon: 'User', permission: 'worker.view' },
    children: [
      {
        path: 'list',
        name: 'WorkerList',
        component: () => import('@/views/worker/list/index.vue'),
        meta: { title: '工人列表', icon: 'List', permission: 'worker.view' }
      },
      {
        path: 'detail/:id',
        name: 'WorkerDetail',
        component: () => import('@/views/worker/detail/index.vue'),
        meta: { title: '工人详情', icon: 'Document', permission: 'worker.view', hidden: true }
      }
    ]
  },
  {
    path: '/attendance',
    component: Layout,
    redirect: '/attendance/list',
    name: 'AttendanceManagement',
    meta: { title: '考勤管理', icon: 'Calendar', permission: 'attendance.view' },
    children: [
      {
        path: 'list',
        name: 'AttendanceList',
        component: () => import('@/views/attendance/list/index.vue'),
        meta: { title: '考勤记录', icon: 'List', permission: 'attendance.view' }
      },
      {
        path: 'statistics',
        name: 'AttendanceStatistics',
        component: () => import('@/views/attendance/statistics/index.vue'),
        meta: { title: '考勤统计', icon: 'PieChart', permission: 'attendance.statistics' }
      }
    ]
  },
  {
    path: '/device',
    component: Layout,
    redirect: '/device/list',
    name: 'DeviceManagement',
    meta: { title: '设备管理', icon: 'Monitor', permission: 'device.view' },
    children: [
      {
        path: 'list',
        name: 'DeviceList',
        component: () => import('@/views/device/list/index.vue'),
        meta: { title: '设备列表', icon: 'List', permission: 'device.view' }
      },
      {
        path: 'detail/:id',
        name: 'DeviceDetail',
        component: () => import('@/views/device/detail/index.vue'),
        meta: { title: '设备详情', icon: 'Document', permission: 'device.view', hidden: true }
      },
      {
        path: 'monitor',
        name: 'DeviceMonitor',
        component: () => import('@/views/device/monitor/index.vue'),
        meta: { title: '设备监控', icon: 'Monitor', permission: 'device.monitor' }
      }
    ]
  },
  {
    path: '/safety',
    component: Layout,
    redirect: '/safety/incident',
    name: 'SafetyManagement',
    meta: { title: '安全管理', icon: 'Warning', permission: 'safety.view' },
    children: [
      {
        path: 'incident',
        name: 'SafetyIncident',
        component: () => import('@/views/safety/incident/index.vue'),
        meta: { title: '安全事件', icon: 'Warning', permission: 'safety.incident.view' }
      },
      {
        path: 'statistics',
        name: 'SafetyStatistics',
        component: () => import('@/views/safety/statistics/index.vue'),
        meta: { title: '安全统计', icon: 'PieChart', permission: 'safety.statistics' }
      }
    ]
  },
  {
    path: '/integration',
    component: Layout,
    redirect: '/integration/government',
    name: 'IntegrationManagement',
    meta: { title: '集成管理', icon: 'Connection', permission: 'integration.view' },
    children: [
      {
        path: 'government',
        name: 'GovernmentPush',
        component: () => import('@/views/integration/government/index.vue'),
        meta: { title: '政府推送', icon: 'Upload', permission: 'integration.government' }
      },
      {
        path: 'iot',
        name: 'IoTIntegration',
        component: () => import('@/views/integration/iot/index.vue'),
        meta: { title: 'IoT集成', icon: 'Connection', permission: 'integration.iot' }
      }
    ]
  },
  {
    path: '/digital-twin',
    component: () => import('@/views/digital-twin/index.vue'),
    name: 'DigitalTwin',
    meta: { title: '数字孪生', icon: 'Monitor', permission: 'digital-twin.view', noCache: true }
  },
  {
    path: '/dashboard',
    component: Layout,
    redirect: '/dashboard/index',
    name: 'DashboardManagement',
    meta: { title: '仪表盘', icon: 'DataAnalysis', permission: 'dashboard.view' },
    children: [
      {
        path: 'index',
        name: 'Dashboard',
        component: () => import('@/views/dashboard/index.vue'),
        meta: { title: '总览', icon: 'DataAnalysis', permission: 'dashboard.view' }
      },
      {
        path: 'project/:id',
        name: 'ProjectDashboard',
        component: () => import('@/views/dashboard/project/index.vue'),
        meta: { title: '项目仪表盘', icon: 'DataAnalysis', permission: 'dashboard.project', hidden: true }
      }
    ]
  }
]

export default constructionRoutes