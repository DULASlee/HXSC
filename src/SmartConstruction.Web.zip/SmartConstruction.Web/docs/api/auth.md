# 认证与用户管理 API

## 1. 用户登录

- **接口路径**：`POST /api/auth/login`
- **功能**：用户登录认证，获取访问令牌
- **请求参数**：

```json
{
  "tenantCode": "SYSTEM",      // 租户代码，必填
  "username": "admin",         // 用户名，必填
  "password": "Admin@123",     // 密码，必填
  "rememberMe": false,         // 记住我，可选
  "deviceId": "web-123456",    // 设备ID，可选
  "deviceType": "Web"          // 设备类型，可选
}
```

- **响应数据**：

```json
{
  "code": 200,
  "message": "登录成功",
  "data": {
    "token": {
      "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
      "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
      "expiresIn": 3600
    },
    "user": {
      "id": "1",
      "username": "admin",
      "displayName": "系统管理员",
      "email": "admin@example.com",
      "mobile": "13800138000",
      "avatar": "/avatar/default.png",
      "status": 1,
      "tenantId": "1",
      "organizationId": "1",
      "organizationPath": "1",
      "roles": [
        {
          "id": "1",
          "code": "ADMIN",
          "name": "管理员",
          "dataScope": "All",
          "status": 1,
          "isSystem": true,
          "createdAt": "2023-01-01T00:00:00Z"
        }
      ],
      "createdAt": "2023-01-01T00:00:00Z"
    },
    "permissions": ["*"],
    "menus": [
      // 菜单数组
    ]
  }
}
```

## 2. 用户登出

- **接口路径**：`POST /api/auth/logout`
- **功能**：用户退出登录，使当前令牌失效
- **请求头**：`Authorization: Bearer {accessToken}`
- **请求参数**：无
- **响应数据**：

```json
{
  "code": 200,
  "message": "登出成功",
  "data": null
}
```

## 3. 获取当前用户信息

- **接口路径**：`GET /api/auth/me`
- **功能**：获取当前登录用户的详细信息
- **请求头**：`Authorization: Bearer {accessToken}`
- **请求参数**：无
- **响应数据**：

```json
{
  "code": 200,
  "message": "操作成功",
  "data": {
    "user": {
      "id": "1",
      "username": "admin",
      "displayName": "系统管理员",
      "email": "admin@example.com",
      "mobile": "13800138000",
      "avatar": "/avatar/default.png",
      "status": 1,
      "tenantId": "1",
      "organizationId": "1",
      "organizationPath": "1",
      "roles": [
        {
          "id": "1",
          "code": "ADMIN",
          "name": "管理员",
          "dataScope": "All",
          "status": 1,
          "isSystem": true,
          "createdAt": "2023-01-01T00:00:00Z"
        }
      ],
      "createdAt": "2023-01-01T00:00:00Z"
    },
    "permissions": ["*"]
  }
}
```

## 4. 刷新访问令牌

- **接口路径**：`POST /api/auth/refresh-token`
- **功能**：使用刷新令牌获取新的访问令牌
- **请求参数**：

```json
{
  "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

- **响应数据**：

```json
{
  "code": 200,
  "message": "刷新成功",
  "data": {
    "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "expiresIn": 3600
  }
}
```

## 5. 获取用户菜单和权限

- **接口路径**：`GET /api/auth/menus`
- **功能**：获取当前用户的菜单和权限列表
- **请求头**：`Authorization: Bearer {accessToken}`
- **请求参数**：无
- **响应数据**：

```json
{
  "code": 200,
  "message": "操作成功",
  "data": {
    "menus": [
      {
        "id": "1",
        "parentId": null,
        "name": "工作台",
        "code": "Dashboard",
        "path": "/dashboard",
        "component": "dashboard/index",
        "icon": "House",
        "type": "Menu",
        "permission": "dashboard.view",
        "sortOrder": 1,
        "isVisible": true,
        "isEnabled": true,
        "isKeepAlive": true,
        "children": []
      },
      // 更多菜单...
    ],
    "permissions": ["dashboard.view", "user.view", "role.view"]
  }
}
```

## 6. 获取用户权限列表

- **接口路径**：`GET /api/auth/permissions`
- **功能**：获取当前用户的权限代码列表
- **请求头**：`Authorization: Bearer {accessToken}`
- **请求参数**：无
- **响应数据**：

```json
{
  "code": 200,
  "message": "操作成功",
  "data": ["dashboard.view", "user.view", "role.view", "user.create", "user.edit"]
}
```

## 7. 验证令牌有效性

- **接口路径**：`GET /api/auth/validate`
- **功能**：验证当前访问令牌是否有效
- **请求头**：`Authorization: Bearer {accessToken}`
- **请求参数**：无
- **响应数据**：

```json
{
  "code": 200,
  "message": "令牌有效",
  "data": {
    "valid": true
  }
}
```

## 8. 获取验证码

- **接口路径**：`GET /api/auth/captcha`
- **功能**：获取图形验证码
- **请求参数**：无
- **响应数据**：

```json
{
  "code": 200,
  "message": "操作成功",
  "data": {
    "key": "captcha:123456",
    "image": "data:image/png;base64,..."  // Base64编码的图片
  }
}
```

## 9. 发送短信验证码

- **接口路径**：`POST /api/auth/sms-code`
- **功能**：发送短信验证码到指定手机号
- **请求参数**：

```json
{
  "mobile": "13800138000"
}
```

- **响应数据**：

```json
{
  "code": 200,
  "message": "验证码已发送",
  "data": null
}
```

## 10. 发送邮箱验证码

- **接口路径**：`POST /api/auth/email-code`
- **功能**：发送验证码到指定邮箱
- **请求参数**：

```json
{
  "email": "user@example.com"
}
```

- **响应数据**：

```json
{
  "code": 200,
  "message": "验证码已发送",
  "data": null
}
```

## 11. 手机号登录

- **接口路径**：`POST /api/auth/login-mobile`
- **功能**：使用手机号和验证码登录
- **请求参数**：

```json
{
  "tenantCode": "SYSTEM",
  "mobile": "13800138000",
  "code": "123456",
  "deviceId": "web-123456",
  "deviceType": "Web"
}
```

- **响应数据**：与普通登录接口相同

## 12. 邮箱登录

- **接口路径**：`POST /api/auth/login-email`
- **功能**：使用邮箱和验证码登录
- **请求参数**：

```json
{
  "tenantCode": "SYSTEM",
  "email": "user@example.com",
  "code": "123456",
  "deviceId": "web-123456",
  "deviceType": "Web"
}
```

- **响应数据**：与普通登录接口相同

## 13. 第三方登录

- **接口路径**：`POST /api/auth/login-third-party`
- **功能**：使用第三方平台授权码登录
- **请求参数**：

```json
{
  "provider": "wechat",  // 可选值: "wechat", "dingtalk", "feishu"
  "code": "授权码",
  "state": "状态码"
}
```

- **响应数据**：与普通登录接口相同

## 14. 忘记密码 - 发送重置邮件

- **接口路径**：`POST /api/auth/forgot-password`
- **功能**：发送密码重置邮件
- **请求参数**：

```json
{
  "tenantCode": "SYSTEM",
  "email": "user@example.com"
}
```

- **响应数据**：

```json
{
  "code": 200,
  "message": "重置邮件已发送",
  "data": null
}
```

## 15. 重置密码

- **接口路径**：`POST /api/auth/reset-password`
- **功能**：使用重置令牌设置新密码
- **请求参数**：

```json
{
  "token": "重置令牌",
  "newPassword": "新密码"
}
```

- **响应数据**：

```json
{
  "code": 200,
  "message": "密码重置成功",
  "data": null
}
```

## 16. 修改密码

- **接口路径**：`PUT /api/auth/change-password`
- **功能**：修改当前用户密码
- **请求头**：`Authorization: Bearer {accessToken}`
- **请求参数**：

```json
{
  "oldPassword": "旧密码",
  "newPassword": "新密码"
}
```

- **响应数据**：

```json
{
  "code": 200,
  "message": "密码修改成功",
  "data": null
}
```

## 17. 绑定手机号

- **接口路径**：`POST /api/auth/bind-mobile`
- **功能**：绑定手机号到当前账号
- **请求头**：`Authorization: Bearer {accessToken}`
- **请求参数**：

```json
{
  "mobile": "13800138000",
  "code": "123456"
}
```

- **响应数据**：

```json
{
  "code": 200,
  "message": "手机号绑定成功",
  "data": null
}
```

## 18. 绑定邮箱

- **接口路径**：`POST /api/auth/bind-email`
- **功能**：绑定邮箱到当前账号
- **请求头**：`Authorization: Bearer {accessToken}`
- **请求参数**：

```json
{
  "email": "user@example.com",
  "code": "123456"
}
```

- **响应数据**：

```json
{
  "code": 200,
  "message": "邮箱绑定成功",
  "data": null
}
```

## 19. 解绑手机号

- **接口路径**：`POST /api/auth/unbind-mobile`
- **功能**：解除当前账号的手机号绑定
- **请求头**：`Authorization: Bearer {accessToken}`
- **请求参数**：

```json
{
  "code": "123456"  // 验证码
}
```

- **响应数据**：

```json
{
  "code": 200,
  "message": "手机号解绑成功",
  "data": null
}
```

## 20. 解绑邮箱

- **接口路径**：`POST /api/auth/unbind-email`
- **功能**：解除当前账号的邮箱绑定
- **请求头**：`Authorization: Bearer {accessToken}`
- **请求参数**：

```json
{
  "code": "123456"  // 验证码
}
```

- **响应数据**：

```json
{
  "code": 200,
  "message": "邮箱解绑成功",
  "data": null
}
``` 