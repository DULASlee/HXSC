<template>
  <el-dropdown 
    class="language-switcher"
    trigger="click"
    @command="handleLanguageChange"
  >
    <el-button text class="language-button">
      <el-icon :size="18">
        <i-carbon-language />
      </el-icon>
      <span class="current-language" v-if="!isMobile">{{ currentLanguageLabel }}</span>
    </el-button>
    
    <template #dropdown>
      <el-dropdown-menu>
        <el-dropdown-item
          v-for="language in languages"
          :key="language.value"
          :command="language.value"
          :class="{ 'is-active': currentLanguage === language.value }"
        >
          <div class="language-option">
            <span class="language-flag">{{ language.flag }}</span>
            <span class="language-label">{{ language.label }}</span>
            <el-icon v-if="currentLanguage === language.value" class="check-icon">
              <Check />
            </el-icon>
          </div>
        </el-dropdown-item>
      </el-dropdown-menu>
    </template>
  </el-dropdown>
</template>

<script setup lang="ts">
import { ref, computed, inject } from 'vue'
import { Check } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import { useAppStore } from '@/stores/app'
import { useI18n } from 'vue-i18n'

const appStore = useAppStore()
const { locale } = useI18n()

// 获取移动端状态
const isMobile = inject('isMobile', false)

// 当前语言
const currentLanguage = ref(appStore.language)

// 支持的语言列表
const languages = [
  {
    value: 'zh-CN',
    label: '简体中文',
    flag: '🇨🇳'
  },
  {
    value: 'en',
    label: 'English',
    flag: '🇺🇸'
  },
  {
    value: 'ja',
    label: '日本語',
    flag: '🇯🇵'
  }
]

// 当前语言标签
const currentLanguageLabel = computed(() => {
  const language = languages.find(lang => lang.value === currentLanguage.value)
  return language ? language.label : '简体中文'
})

// 处理语言切换
const handleLanguageChange = (languageCode: string) => {
  if (languageCode === currentLanguage.value) {
    return
  }
  
  const language = languages.find(lang => lang.value === languageCode)
  if (!language) {
    return
  }
  
  // 更新应用语言
  appStore.setLanguage(languageCode as any)
  currentLanguage.value = languageCode
  
  // 更新i18n语言
  locale.value = languageCode
  
  // 更新HTML lang属性
  document.documentElement.lang = languageCode
  
  // 显示成功消息
  ElMessage.success(`语言已切换到${language.label}`)
  
  // 可选：重新加载页面以应用语言变化
  // location.reload()
}
</script>

<style lang="scss" scoped>
.language-switcher {
  .language-button {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 36px;
    padding: 0 var(--spacing-small);
    border-radius: var(--border-radius-base);
    color: var(--text-color-regular);
    transition: var(--transition-base);
    
    &:hover {
      background-color: var(--fill-color-light);
      color: var(--primary-color);
    }
    
    .current-language {
      margin-left: var(--spacing-extra-small);
      font-size: var(--font-size-small);
      white-space: nowrap;
    }
  }
}

:deep(.el-dropdown-menu) {
  .language-option {
    display: flex;
    align-items: center;
    width: 100%;
    padding: 0;
    
    .language-flag {
      margin-right: var(--spacing-small);
      font-size: var(--font-size-base);
    }
    
    .language-label {
      flex: 1;
      font-size: var(--font-size-small);
    }
    
    .check-icon {
      font-size: var(--font-size-small);
      color: var(--primary-color);
    }
  }
  
  .el-dropdown-menu__item {
    &.is-active {
      background-color: var(--primary-color-light-9, #ecf5ff);
      color: var(--primary-color);
    }
    
    &:hover {
      background-color: var(--fill-color-light);
    }
  }
}

// 移动端适配
@include respond-to(xs) {
  .language-switcher {
    .language-button {
      width: 36px;
      padding: 0;
      
      .current-language {
        display: none;
      }
    }
  }
}

// 语言切换动画
.language-switcher {
  .language-button {
    position: relative;
    overflow: hidden;
    
    &::before {
      content: '';
      position: absolute;
      top: 50%;
      left: 50%;
      width: 0;
      height: 0;
      background-color: var(--primary-color);
      border-radius: 50%;
      transform: translate(-50%, -50%);
      transition: all 0.3s ease;
      opacity: 0.1;
    }
    
    &:active::before {
      width: 100px;
      height: 100px;
    }
  }
}

// 暗色主题适配
[data-theme="dark"] {
  .language-switcher {
    .language-button {
      &:hover {
        background-color: var(--fill-color-dark);
      }
    }
  }
}
</style>