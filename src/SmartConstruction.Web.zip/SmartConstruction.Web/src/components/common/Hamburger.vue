<template>
  <div style="padding: 0 15px;" @click="toggleClick">
    <el-icon :size="20">
      <component :is="isActive ? 'fold' : 'expand'" />
    </el-icon>
  </div>
</template>

<script lang="ts">
export default {
  name: 'Hamburger'
}
</script>

<script setup lang="ts">
defineProps({
  isActive: {
    type: Boolean,
    default: false
  }
});

const emit = defineEmits(['toggleClick']);

const toggleClick = () => {
  emit('toggleClick');
};
</script>

<style scoped>
.hamburger {
  display: inline-block;
  vertical-align: middle;
  width: 20px;
  height: 20px;
}
</style> 