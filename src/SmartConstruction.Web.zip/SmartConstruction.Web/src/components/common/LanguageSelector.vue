<template>
  <el-dropdown @command="handleLanguageChange">
    <span class="language-selector">
      <el-icon><Globe /></el-icon>
      {{ getCurrentLanguageName() }}
      <el-icon class="el-icon--right"><ArrowDown /></el-icon>
    </span>
    <template #dropdown>
      <el-dropdown-menu>
        <el-dropdown-item
          command="zh-CN"
          :class="{ 'is-active': appStore.language === 'zh-CN' }"
        >
          🇨🇳 简体中文
        </el-dropdown-item>
        <el-dropdown-item
          command="en-US"
          :class="{ 'is-active': appStore.language === 'en-US' }"
        >
          🇺🇸 English
        </el-dropdown-item>
        <el-dropdown-item
          command="ja-JP"
          :class="{ 'is-active': appStore.language === 'ja-JP' }"
        >
          🇯🇵 日本語
        </el-dropdown-item>
      </el-dropdown-menu>
    </template>
  </el-dropdown>
</template>

<script setup lang="ts">
import { useAppStore } from "@/stores/app";
import { useI18nStore } from "@/stores/i18n";
import type { LanguageType } from "@/stores/app";

const appStore = useAppStore();
const i18nStore = useI18nStore();

const languageNames = {
  "zh-CN": "简体中文",
  "en-US": "English",
  "ja-JP": "日本語",
};

const getCurrentLanguageName = () => {
  return languageNames[appStore.language] || languageNames["zh-CN"];
};

const handleLanguageChange = (language: LanguageType) => {
  appStore.setLanguage(language);
  i18nStore.setLocale(language);

  // 可以在这里添加Element Plus的语言切换
  // 需要动态导入Element Plus的语言包
};
</script>

<style scoped>
.language-selector {
  display: flex;
  align-items: center;
  cursor: pointer;
  padding: 0 12px;
  color: var(--app-text-color-regular);

  &:hover {
    color: var(--el-color-primary);
  }
}

:deep(.el-dropdown-menu__item) {
  &.is-active {
    color: var(--el-color-primary);
    background-color: var(--el-color-primary-light-9);
  }
}
</style>
