// =============================================
// 路由配置 - 多租户权限管理系统
// =============================================
import { createRouter, createWebHistory } from 'vue-router'
import type { RouteRecordRaw } from 'vue-router'
import { useMenuStore } from '@/stores/menu'
import { useUserStore } from '@/stores/user'

// 延迟加载布局组件，避免循环依赖导致的初始化顺序错误
const Layout = () => import('@/layouts/DefaultLayout.vue')

// 静态路由
export const constantRoutes: RouteRecordRaw[] = [
  {
    path: '/redirect',
    component: Layout,
    meta: { hidden: true },
    children: [
      {
        path: '/redirect/:path(.*)',
        component: () => import('@/views/redirect/index.vue')
      }
    ]
  },
  {
    path: '/login',
    name: 'Login',
    component: () => import('@/views/login/index.vue'),
    meta: { title: '登录', hidden: true }
  },
  {
    path: '/403',
    name: '403',
    component: () => import('@/views/error/403.vue'),
    meta: { title: '无权限', hidden: true }
  },
  {
    path: '/404',
    name: '404',
    component: () => import('@/views/error/404.vue'),
    meta: { title: '页面不存在', hidden: true }
  },
  {
    path: '/',
    name: 'Root', // 为根布局路由添加唯一的名称
    component: Layout,
    redirect: '/dashboard',
    children: [
      {
        path: 'dashboard',
        name: 'Dashboard',
        component: () => import('@/views/dashboard/index.vue'),
        meta: { title: '工作台', icon: 'House', affix: true }
      }
    ]
  },
  {
    path: '/profile',
    component: Layout,
    redirect: '/profile/index',
    meta: { hidden: true },
    children: [
      {
        path: 'index',
        name: 'Profile',
        component: () => import('@/views/profile/index.vue'),
        meta: { title: '个人中心', icon: 'User' }
      }
    ]
  }
]

// 导入智慧工地路由
import constructionRoutes from './modules/construction'

// 动态路由（根据权限动态加载）
export const asyncRoutes: RouteRecordRaw[] = [
  ...constructionRoutes,
  // 兜底路由 - 捕获所有未匹配的路径
  {
    path: '/:pathMatch(.*)*',
    name: 'NotFound',
    component: () => import('@/views/error/404.vue'),
    meta: { title: '页面不存在', hidden: true }
  }
]

/// <summary>
/// 获取活跃菜单路径 - 处理多级路由激活逻辑
/// </summary>
function getActiveMenuPath(route: any): string {
  const { matched, meta, path } = route
  
  // 1. 优先使用路由元数据中的activeMenu
  if (meta?.activeMenu) {
    console.log(`[菜单激活] 使用自定义激活菜单: ${meta.activeMenu}`)
    return meta.activeMenu
  }
  
  // 2. 处理三级及以上路由 - 激活父级菜单
  if (matched.length >= 3) {
    // 找到有效的父级路由（排除根路由）
    const parentRoute = matched.find((route: any, index: any) => {
      return index > 0 && route.meta?.title && !route.meta?.hidden
    })
    
    if (parentRoute) {
      console.log(`[菜单激活] 多级路由使用父路径激活: ${parentRoute.path}`)
      return parentRoute.path
    }
  }
  
  // 3. 默认使用当前路径
  return path
}

/// <summary>
/// 路由守卫 - 确保菜单状态同步和权限验证
/// </summary>
const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: constantRoutes,
  scrollBehavior: () => ({ top: 0 })
})

router.beforeEach(async (to, from, next) => {
  const userStore = useUserStore()
  const menuStore = useMenuStore()
  
  console.log(`[路由跳转] ${from.path} -> ${to.path}`)
  
  // 1. 白名单路由直接放行
  const whiteList = ['/login', '/404', '/403']
  if (whiteList.includes(to.path)) {
    next()
    return
  }
  
  // 2. [终极军改] 令牌优先，特事特办！
  // 直接从 localStorage 读取 token，彻底绕开 Pinia 初始化延迟问题。
  let token = ''
  try {
    const userStateString = localStorage.getItem('user')
    if (userStateString) {
      token = JSON.parse(userStateString).token
    }
  } catch (e) {
    console.error('[路由守卫] 从localStorage解析token失败:', e)
  }

  if (!token) {
    console.log('[路由守卫] 用户未登录 (localStorage 无 token)，跳转到登录页')
    next(`/login?redirect=${to.path}`)
    return
  }
  
  // 3. 确保菜单数据已加载
  if (menuStore.menus.length === 0) {
    try {
      console.log('[路由守卫] 菜单数据未加载，开始获取菜单')
      // fetchUserMenus 会在内部获取菜单、生成并存储路由
      await menuStore.fetchUserMenus()
      
      // 直接从 store 中获取已生成的路由
      // addRoutes(menuStore.routes as any as RouteRecordRaw[]) // This line is removed as per the new_code
      console.log('[路由守卫] 动态路由已添加，重新导航')
      
      // 使用 replace: true, 这样浏览器历史记录就不会留下这次重定向
      next({ ...to, replace: true })
      return
      
    } catch (error) {
      console.error('[路由守卫] 获取菜单或生成路由失败:', error)
      // [终极军改] 画龙点睛之笔！
      // 获取菜单失败（通常是token失效），不再是简单踢回登录页，
      // 而是先“撤销军籍”（清空用户信息和token），再让他去“重新入伍”（登录）。
      // 这彻底斩断了“无效token -> 循环401 -> 循环登录”的死循环！
      await (userStore as any).resetUser() 
      next(`/login?redirect=${to.path}`)
      return
    }
  }
  
  // 4. 如果代码能走到这里，说明令牌有效，菜单也已加载
  console.log('[路由守卫] 令牌有效，菜单已加载，准予放行')
  
  // 路由匹配验证
  if (to.matched.length === 0) {
    console.error(`[路由错误] 未找到匹配路由: ${to.path}`)
    next('/404')
    return
  }
  
  // 5. 权限验证
  const requiredPermissions = to.meta?.permissions as string[]
  if (requiredPermissions && requiredPermissions.length > 0) {
    const hasPermission = requiredPermissions.some(permission => 
      menuStore.hasPermission(permission)
    )
    
    if (!hasPermission) {
      console.warn(`[权限检查] 无权限访问: ${to.path}`)
      next('/403')
      return
    }
  }
  
  // 6. 设置菜单激活状态
  const activeMenuPath = getActiveMenuPath(to)
  to.meta = { ...to.meta, activeMenuPath }
  
  console.log(`[路由激活] 当前激活菜单: ${activeMenuPath}`)
  console.log("[路由追踪]", to.matched.map(r => `${r.path}(${String(r.name)})`))
  
  next()
})

/// <summary>
/// 路由错误处理
/// </summary>
router.onError((error) => {
  console.error('[路由异常]', error)
  // 可以在这里添加错误上报逻辑
  if (error.message.includes('Loading chunk')) {
    window.location.reload()
  }
})

/// <summary>
/// 重置路由 - 登出时清理动态路由
/// </summary>
export function resetRouter() {
  const newRouter = createRouter({
    history: createWebHistory(import.meta.env.BASE_URL),
    routes: constantRoutes,
    scrollBehavior: () => ({ top: 0 })
  })
  
  // 清理动态路由
  ;(router as any).matcher = (newRouter as any).matcher
  
  // 清理路由缓存
  if (router.currentRoute.value.path !== '/login') {
    router.replace('/login')
  }
  
  console.log('[路由重置] 路由已重置为初始状态')
}

/// <summary>
/// 添加动态路由的辅助函数
/// </summary>
export function addRoutes(routes: RouteRecordRaw[]) {
  if (!routes || routes.length === 0) {
    console.warn('[动态路由] 尝试添加空路由列表，已中止');
    return;
  }

  const parentRouteName = 'Root'; // 明确指定父路由的名称
  if (!router.hasRoute(parentRouteName)) {
    console.error(`[动态路由错误] 无法找到名为 "${parentRouteName}" 的父路由！请检查静态路由配置。`);
    return;
  }

  routes.forEach(route => {
    try {
      // 检查路由是否已存在，避免重复添加
      if (router.hasRoute(route.name || route.path)) {
        console.warn(`[动态路由] 跳过已存在的路由: ${String(route.name) || route.path}`);
        return;
      }
      // 将所有动态路由作为 'Root' 路由的子路由添加
      router.addRoute(parentRouteName, route);
      console.log(`[动态路由] ✅ 已添加: ${String(route.name) || route.path} -> 子路由 of ${parentRouteName}`);
    } catch (error) {
      console.error(`[动态路由错误] 添加失败:`, route, error);
    }
  });

  // [最终调试] 打印所有路由，用于核对最终的路由结构
  console.log('[路由结构总览]', router.getRoutes().map(r => ({ 
    name: r.name, 
    path: r.path, 
    children: r.children.map(c => ({ name: c.name, path: c.path }))
  })));
}

/// <summary>
/// 获取所有路由
/// </summary>
export function getRoutes(): RouteRecordRaw[] {
  return router.getRoutes()
}

export default router