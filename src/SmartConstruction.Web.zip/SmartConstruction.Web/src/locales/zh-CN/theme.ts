// 主题相关翻译
export default {
  theme: {
    light: '亮色主题',
    dark: '暗色主题',
    businessBlue: '商务蓝主题'
  }
} 