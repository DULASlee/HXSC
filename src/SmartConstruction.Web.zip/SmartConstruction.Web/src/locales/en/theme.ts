// Theme-related translations
export default {
  theme: {
    light: 'Light Theme',
    dark: 'Dark Theme',
    businessBlue: 'Business Blue'
  }
} 