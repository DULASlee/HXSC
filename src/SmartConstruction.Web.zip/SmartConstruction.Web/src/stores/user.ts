import { defineStore } from 'pinia';
import { ref, computed } from 'vue';
import router, { resetRouter } from '@/router';
import { ElMessage } from 'element-plus';
import { PermissionService } from '@/services/permission';
import { useMenuStore } from './menu';
import { login as loginApi, logout as logoutApi } from '@/api/modules/auth';
import {
  getCurrentUser,
  changePassword as changePasswordApi,
  resetPassword as resetPasswordApi
} from '@/api/modules/user';
import type { LoginRequest, User, Tenant } from '@/types/global';

// =============================================
// 手动状态持久化：应用启动时从 localStorage 恢复状态
// =============================================
const getInitialState = (): UserState => {
  try {
    const storedState = localStorage.getItem('user');
    if (storedState) {
      const parsedState = JSON.parse(storedState);
      // 简单验证一下 token 是否存在
      if (parsedState.token) {
        console.log('✅ [Auth] 从 localStorage 恢复用户状态:', parsedState);
        return parsedState;
      }
    }
  } catch (e) {
    console.error('❌ [Auth] 从 localStorage 恢复状态失败:', e);
  }

  // 默认初始状态
  return {
    token: '',
    refreshToken: '',
    userInfo: null,
    currentTenant: null,
    permissions: [],
    roles: [],
    loginTime: null
  };
};


interface UserState {
  token: string;
  refreshToken: string;
  userInfo: User | null;
  currentTenant: Tenant | null;
  permissions: string[];
  roles: string[];
  loginTime: number | null;
}

export const useUserStore = defineStore('user', {
  state: (): UserState => getInitialState(),

  getters: {
    isLoggedIn: (state) => !!state.token,
    userName: (state) => state.userInfo?.displayName || state.userInfo?.username || '',
    avatar: (state) => state.userInfo?.avatar || '',
    tenantName: (state) => state.currentTenant?.name || '',
    hasPermission: (state) => (permission: string) => {
      if (!permission) return true;
      return state.permissions.includes(permission);
    },
    hasRole: (state) => (role: string) => {
      return state.roles.includes(role);
    },
    dataScope: (state) => {
      return state.userInfo?.roles?.[0]?.dataScope || 'Self';
    }
  },

  actions: {
    /**
     * @description 用户登录
     * @param {LoginRequest} loginForm - 登录表单
     */
    async login(loginForm: LoginRequest) {
      try {
        console.log('🚀 [Auth] 开始登录请求:', loginForm);

        // http.ts 拦截器会处理外层包装，这里拿到的是完整的 ApiResult 对象
        const response = await loginApi(loginForm) as any;
        console.log('✅ [Auth] 登录接口返回的完整响应:', response);

        // [最终修正] 从完整的 ApiResult 中解构出真正的核心数据 data
        const responseData = response.data;
        if (!responseData) {
          throw new Error('登录响应中缺少核心 data 对象');
        }

        // 从核心数据中解析 token
        const tokenStr = responseData.token;
        const refreshTokenStr = responseData.refreshToken;

        if (!tokenStr) {
          throw new Error('登录响应的核心数据中缺少有效的token信息');
        }

        // 1. 立即更新 Pinia State
        this.token = tokenStr;
        this.refreshToken = refreshTokenStr;
        this.loginTime = Date.now();
        this.userInfo = responseData.user;
        this.roles = responseData.user?.roles?.map((r:any) => r.code) || [];
        this.permissions = responseData.permissions || [];
        this.currentTenant = {
          id: responseData.tenantId,
          code: responseData.tenantCode,
          name: responseData.tenantCode === 'SYSTEM' ? '系统管理租户' : (responseData.user?.organizationName || ''),
          status: 1,
          createdAt: new Date().toISOString(),
          isolationMode: 'Shared', // 补充默认值以满足类型要求
          logo: '' // 补充默认值以满足类型要求
        };

        // 2. 将所有核心状态同步固化到 localStorage，确保刷新后状态不丢失
        try {
          const persistentState = {
            token: this.token,
            refreshToken: this.refreshToken,
            loginTime: this.loginTime,
            currentTenant: this.currentTenant,
            userInfo: this.userInfo,
            permissions: this.permissions,
            roles: this.roles
          };
          localStorage.setItem('user', JSON.stringify(persistentState));
          console.log('💾 [Auth] 已将完整的用户状态固化到 localStorage');
        } catch (e) {
          console.error('[持久化失败] 无法写入 user state 到 localStorage:', e);
        }

        // 3. 处理菜单和动态路由
        const menuStore = useMenuStore();
        if (responseData.menus && responseData.menus.length > 0) {
          console.log('📦 [Auth] 使用登录响应中的菜单数据生成路由:', responseData.menus.length, '个');
          await menuStore.generateRoutes(responseData.menus);
        } else {
          console.warn('⚠️ [Auth] 登录响应中无菜单数据，将由路由守卫加载');
        }

        console.log('🎉 [Auth] 登录流程成功完成，用户信息:', this.userInfo);
        return { success: true };

      } catch (error: any) {
        console.error('❌ [Auth] 登录流程失败:', error);
        return { success: false, message: error.message || '登录失败' };
      }
    },

      /**
       * @description 获取当前用户信息
       */
      async getUserInfo() {
        try {
          const { data } = (await getCurrentUser()) as any;
          if (data && data.user) {
            this.userInfo = data.user;
            this.permissions = data.permissions || [];
            this.roles = data.user.roles?.map((r: any) => r.code) || [];
          } else {
            throw new Error('API返回的用户信息格式不正确');
          }
        } catch (error) {
          console.error('获取用户信息失败:', error);
          await this.logout();
          throw error;
        }
      },

      /**
       * @description 用户登出
       */
      async logout() {
        try {
          await logoutApi();
        } catch (error) {
          console.error('登出接口调用失败:', error);
        } finally {
          this.resetUser();
          resetRouter();
          router.push('/login');
        }
      },

      /**
       * @description 重置用户所有状态
       */
      resetUser() {
        // 1. 清理 localStorage
        try {
          localStorage.removeItem('user');
        } catch (e) {
          console.error('[持久化失败] 无法重置 user state 到 localStorage:', e);
        }

        // 2. 重置 Pinia state
        this.token = '';
        this.refreshToken = '';
        this.userInfo = null;
        this.currentTenant = null;
        this.permissions = [];
        this.roles = [];
        this.loginTime = null;

        // 3. 清理菜单状态
        const menuStore = useMenuStore();
        menuStore.clearMenus();
        
        console.log('🧹 [Auth] 用户状态已完全重置');
      },

      /**
       * @description 切换租户
       * @param {Tenant} tenant - 目标租户
       */
      async switchTenant(tenant: Tenant) {
        this.currentTenant = tenant;
        await this.getUserInfo();
        ElMessage.success(`已切换到 ${tenant.name}`);
        router.push('/');
      },

      /**
       * @description 检查权限（从服务器验证）
       * @param {string} resourceCode - 资源编码
       * @param {Record<string, any>} [context] - 上下文
       */
      async checkPermission(resourceCode: string, context?: Record<string, any>): Promise<boolean> {
        return await PermissionService.checkPermission(resourceCode, context);
      },

      /**
       * @description 检查是否拥有任意一个权限
       * @param {string[]} resourceCodes - 资源编码列表
       */
      async hasAnyPermission(resourceCodes: string[]): Promise<boolean> {
        return await PermissionService.hasAnyPermission(resourceCodes);
      },

      /**
       * @description 检查是否拥有所有权限
       * @param {string[]} resourceCodes - 资源编码列表
       */
      async hasAllPermissions(resourceCodes: string[]): Promise<boolean> {
        return await PermissionService.hasAllPermissions(resourceCodes);
      },

      /**
       * @description 检查数据范围权限
       * @param {string} [targetUserId] - 目标用户ID
       * @param {string} [targetOrgId] - 目标组织ID
       */
      checkDataScope(targetUserId?: string, targetOrgId?: string): boolean {
        if (!this.userInfo) return false;
        
        return PermissionService.checkDataScope(
          this.dataScope,
          this.userInfo.id,
          targetUserId,
          targetOrgId
        );
      },

      /**
       * @description 刷新用户权限
       */
      async refreshPermissions() {
        try {
          const permissions = await PermissionService.getUserPermissions();
          this.permissions = permissions;
          return permissions;
        } catch (error) {
          console.error('刷新权限失败:', error);
          return [];
        }
      },

      /**
       * @description 刷新用户菜单
       */
      async refreshMenus() {
        try {
          const menus = await PermissionService.getUserMenus();
          const menuStore = useMenuStore();
          await menuStore.generateRoutes(menus);
          return menus;
        } catch (error) {
          console.error('刷新菜单失败:', error);
          return [];
        }
      },

      /**
       * @description 检查是否为系统管理员
       */
      isSystemAdmin(): boolean {
        return this.roles.includes('SYSTEM_ADMIN') || this.roles.includes('SUPER_ADMIN');
      },

      /**
       * @description 检查是否为租户管理员
       */
      isTenantAdmin(): boolean {
        return this.roles.includes('TENANT_ADMIN') || this.roles.includes('ADMIN');
      },

      /**
       * @description 获取用户组织路径
       */
      getOrganizationPath(): string[] {
        if (!this.userInfo?.organizationPath) return [];
        return (this.userInfo.organizationPath as unknown as string).split('/');
      },

      /**
       * @description 检查是否在指定组织下
       * @param {string} organizationId - 组织ID
       */
      isInOrganization(organizationId: string): boolean {
        const orgPath = this.getOrganizationPath();
        return orgPath.includes(organizationId);
      }
    }
  // 彻底移除 pinia-plugin-persistedstate 的配置
  // persist: { ... }
});
