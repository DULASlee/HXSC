import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import type { RouteRecordRaw } from 'vue-router'
// 使用惰性加载来避免循环依赖
const getDefaultLayout = () => import('@/layouts/DefaultLayout.vue')

// 菜单类型定义
export interface Menu {
  id: string
  code: string
  name: string
  type: string
  parentId?: string
  path?: string
  component?: string
  icon?: string
  permission?: string
  sortOrder: number
  isEnabled: boolean
  isVisible: boolean
  isKeepAlive: boolean
  isExternal: boolean
  createdAt: string
  children?: Menu[]
}

export interface MenuRoute extends RouteRecordRaw {
  meta: {
    title: string
    icon?: string
    hidden?: boolean
    activeMenu?: string
    keepAlive?: boolean
    roles?: string[]
    permissions?: string[]
    sortOrder?: number
    menuData?: Menu
  }
  children?: MenuRoute[]
}

/// <summary>
/// 菜单状态管理Store
/// </summary>
export const useMenuStore = defineStore('menu', () => {
  // 状态
  const menus = ref<Menu[]>([])
  const routes = ref<MenuRoute[]>([])
  const permissions = ref<string[]>([])
  const loading = ref(false)
  const isRoutesGenerated = ref(false)
  const isInitializing = ref(false)
  const lastUpdateTime = ref<number>(0)

  // 常量定义
  const CACHE_KEY = {
    MENU_DATA: 'smart_construction_menu_data',
    PERMISSIONS: 'smart_construction_permissions',
    ROUTES_GENERATED: 'smart_construction_routes_generated',
    LAST_UPDATE: 'smart_construction_menu_last_update'
  }
  
  const CACHE_EXPIRE_TIME = 30 * 60 * 1000 // 30分钟缓存过期

  // 计算属性
  const menuTree = computed(() => {
    return buildMenuTree(menus.value)
  })

  const flatMenus = computed(() => {
    return flattenMenus(menus.value)
  })

  /// <summary>
  /// 构建菜单树
  /// </summary>
  function buildMenuTree(menuList: Menu[]): Menu[] {
    if (!menuList || menuList.length === 0) return []
    
    const menuMap = new Map<string, Menu>()
    const rootMenus: Menu[] = []

    // 创建菜单映射
    menuList.forEach(menu => {
      menuMap.set(menu.id, { ...menu, children: [] })
    })

    // 构建树结构
    menuList.forEach(menu => {
      const menuItem = menuMap.get(menu.id)!
      
      if (menu.parentId && menuMap.has(menu.parentId)) {
        const parent = menuMap.get(menu.parentId)!
        if (!parent.children) {
          parent.children = []
        }
        parent.children.push(menuItem)
      } else {
        rootMenus.push(menuItem)
      }
    })

    return rootMenus.sort((a, b) => a.sortOrder - b.sortOrder)
  }

  /// <summary>
  /// 扁平化菜单
  /// </summary>
  function flattenMenus(menuList: Menu[]): Menu[] {
    const result: Menu[] = []
    
    function traverse(menus: Menu[]) {
      menus.forEach(menu => {
        result.push(menu)
        if (menu.children && menu.children.length > 0) {
          traverse(menu.children)
        }
      })
    }
    
    traverse(menuList)
    return result
  }

  /// <summary>
  /// 菜单转路由 - 简化版，只检查数据存在性
  /// </summary>
  function menusToRoutes(menuList: Menu[]): MenuRoute[] {
    if (!menuList || menuList.length === 0) {
      console.warn('menusToRoutes: menuList 为空')
      return []
    }

    console.log(`🔧 [菜单转路由] 开始处理 ${menuList.length} 个菜单项`)

    const routes = menuList
      .filter(menu => menu && menu.name) // 只检查菜单项存在且有名称
      .map(menu => {
        const route: MenuRoute = {
          path: menu.path || `/${menu.code || menu.id}`,
          name: menu.code || menu.name || `menu_${menu.id}`,
          component: menu.component 
            ? resolveComponent(menu.component)
            : getDefaultLayout,
          meta: {
            title: menu.name || '未命名菜单',
            icon: menu.icon,
            hidden: !menu.isVisible,
            activeMenu: menu.path,
            keepAlive: menu.isKeepAlive,
            permissions: menu.permission ? [menu.permission] : [],
            sortOrder: menu.sortOrder || 0,
            menuData: menu 
          }
        }

        // 处理子菜单
        if (menu.children && menu.children.length > 0) {
          const childRoutes = menusToRoutes(menu.children)
          if (childRoutes.length > 0) {
            route.children = childRoutes
          }
        }

        console.log(`✅ [路由生成] ${menu.name} -> ${route.path}`)
        return route
      })

    console.log(`🚀 [菜单转路由] 成功生成 ${routes.length} 个路由`)
    return routes.sort((a, b) => (a.meta?.sortOrder || 0) - (b.meta?.sortOrder || 0))
  }

  /// <summary>
  /// 解析组件路径 - 增强容错处理
  /// </summary>
  const views = import.meta.glob('@/views/**/*.vue')

  function resolveComponent(componentPath: string) {
    if (!componentPath) {
      console.warn('resolveComponent: componentPath 为空')
      return getDefaultLayout
    }

    // 如果菜单配置的是 "Layout"，直接返回主布局组件
    if (componentPath.toLowerCase() === 'layout') {
      return getDefaultLayout
    }

    // 去掉开头的 @ 或 /src，标准化路径
    let cleanPath = componentPath
      .replace(/^@?\/src\//, '')
      .replace(/^@?\/views\//, '')
      .replace(/^views\//, '')
      .replace(/\.vue$/, '')

    // 尝试多种路径组合
    const possiblePaths = [
      `@/views/${cleanPath}.vue`,
      `@/views/${cleanPath}/index.vue`,
      `/src/views/${cleanPath}.vue`,
      `/src/views/${cleanPath}/index.vue`
    ]

    for (const path of possiblePaths) {
      const component = views[path]
      if (component) {
        console.log(`组件解析成功: ${componentPath} -> ${path}`)
        return component
      }
    }

    console.error(`Component not found for path: ${componentPath}, tried:`, possiblePaths)
    // 返回占位符组件而非404，防止页面完全崩溃
    return () => import('@/components/PlaceholderView.vue').catch(() => 
      ({ template: '<div class="placeholder-view">组件加载失败：{{componentPath}}</div>', data: () => ({ componentPath }) })
    )
  }

  /// <summary>
  /// 保存菜单数据到本地存储
  /// </summary>
  function saveMenuDataToCache(menuData: Menu[], permissionData: string[]) {
    try {
      const cacheData = {
        menus: menuData,
        permissions: permissionData,
        timestamp: Date.now(),
        version: '1.0'
      }
      
      localStorage.setItem(CACHE_KEY.MENU_DATA, JSON.stringify(cacheData))
      localStorage.setItem(CACHE_KEY.ROUTES_GENERATED, JSON.stringify(isRoutesGenerated.value))
      localStorage.setItem(CACHE_KEY.LAST_UPDATE, Date.now().toString())
      
      console.log('菜单数据已缓存到本地存储')
    } catch (error) {
      console.error('保存菜单数据到缓存失败:', error)
    }
  }

  /// <summary>
  /// 从本地存储加载菜单数据
  /// </summary>
  function loadMenuDataFromCache(): { menus: Menu[], permissions: string[] } | null {
    try {
      const cachedData = localStorage.getItem(CACHE_KEY.MENU_DATA)
      const routesGenerated = localStorage.getItem(CACHE_KEY.ROUTES_GENERATED)
      const lastUpdate = localStorage.getItem(CACHE_KEY.LAST_UPDATE)
      
      if (!cachedData) return null
      
      const parsedData = JSON.parse(cachedData)
      const now = Date.now()
      
      // 检查缓存是否过期
      if (parsedData.timestamp && (now - parsedData.timestamp) > CACHE_EXPIRE_TIME) {
        console.log('菜单缓存已过期，将重新获取')
        clearMenuCache()
        return null
      }
      
      // 验证数据完整性
      if (!parsedData.menus || !Array.isArray(parsedData.menus)) {
        console.warn('缓存的菜单数据格式错误')
        clearMenuCache()
        return null
      }
      
      // 恢复路由生成状态
      if (routesGenerated) {
        isRoutesGenerated.value = JSON.parse(routesGenerated)
      }
      
      // 恢复最后更新时间
      if (lastUpdate) {
        lastUpdateTime.value = parseInt(lastUpdate)
      }
      
      console.log('成功从缓存加载菜单数据')
      return {
        menus: parsedData.menus,
        permissions: parsedData.permissions || []
      }
    } catch (error) {
      console.error('从缓存加载菜单数据失败:', error)
      clearMenuCache()
      return null
    }
  }

  /// <summary>
  /// 清除菜单缓存
  /// </summary>
  function clearMenuCache() {
    Object.values(CACHE_KEY).forEach(key => {
      localStorage.removeItem(key)
    })
    console.log('菜单缓存已清除')
  }

  /// <summary>
  /// 获取用户菜单
  /// </summary>
  async function fetchUserMenus() {
    loading.value = true
    try {
      console.log('开始获取用户菜单数据')
      
      // 首先尝试从缓存加载
      const cachedData = loadMenuDataFromCache()
      if (cachedData && cachedData.menus.length > 0) {
        menus.value = cachedData.menus
        permissions.value = cachedData.permissions
        routes.value = menusToRoutes(menus.value)
        
        console.log('使用缓存的菜单数据')
        
        // 异步更新最新数据（后台更新）
        setTimeout(() => {
          fetchMenuDataFromApiAsync()
        }, 1000)
        
        return {
          menus: menus.value,
          routes: routes.value,
          permissions: permissions.value
        }
      }
      
      // 如果没有缓存，从API获取
      return await fetchMenuDataFromApi()
    } catch (error) {
      console.error('Failed to fetch user menus:', error)
      
      // 失败时尝试使用任何可用的缓存数据
      const fallbackData = loadMenuDataFromCache()
      if (fallbackData) {
        menus.value = fallbackData.menus
        permissions.value = fallbackData.permissions
        routes.value = menusToRoutes(menus.value)
        console.log('使用缓存数据作为降级方案')
      }
      
      throw error
    } finally {
      loading.value = false
    }
  }
  
  /// <summary>
  /// 从API获取菜单数据
  /// </summary>
  async function fetchMenuDataFromApi() {
    try {
      // 动态导入API函数，打破循环依赖
      const { getUserMenus } = await import('@/api/modules/menu');
      const response = await getUserMenus();

      if (response) {
        // 适配API响应结构
        const menuData = response.menus || []
        const permissionData = response.permissions || []

        if (!Array.isArray(menuData)) {
          throw new Error('API返回的菜单数据格式错误')
        }
        
        menus.value = menuData
        permissions.value = permissionData
        routes.value = menusToRoutes(menus.value)
        lastUpdateTime.value = Date.now()
        
        // 保存到缓存
        saveMenuDataToCache(menuData, permissionData)
        
        console.log('解析后的菜单数据:', menus.value)
        console.log('解析后的路由:', routes.value)
        
        return {
          menus: menus.value,
          routes: routes.value,
          permissions: permissions.value
        }
      } else {
        throw new Error('获取菜单数据失败');
      }
    } catch (error) {
      console.error('Failed to fetch menu data from API:', error);
      throw error;
    }
  }
  
  /// <summary>
  /// 异步更新菜单数据（不阻塞UI）
  /// </summary>
  async function fetchMenuDataFromApiAsync() {
    try {
      const now = Date.now()
      
      // 如果上次更新时间距今超过5分钟，则更新
      if ((now - lastUpdateTime.value) > 5 * 60 * 1000) {
        console.log('开始后台更新菜单数据')
        await fetchMenuDataFromApi()
        console.log('菜单数据已在后台更新')
      }
    } catch (error) {
      console.warn('后台更新菜单数据失败', error)
    }
  }

  /// <summary>
  /// 检查权限
  /// </summary>
  function hasPermission(permission: string): boolean {
    if (!permission) return true
    return permissions.value.includes(permission)
  }

  /// <summary>
  /// 检查多个权限（或关系）
  /// </summary>
  function hasAnyPermission(permissionList: string[]): boolean {
    return permissionList.some(permission => hasPermission(permission))
  }

  /// <summary>
  /// 检查多个权限（且关系）
  /// </summary>
  function hasAllPermissions(permissionList: string[]): boolean {
    return permissionList.every(permission => hasPermission(permission))
  }

  /// <summary>
  /// 根据路径查找菜单
  /// </summary>
  function findMenuByPath(path: string): Menu | undefined {
    return flatMenus.value.find(menu => menu.path === path)
  }

  /// <summary>
  /// 根据权限过滤菜单
  /// </summary>
  function filterMenusByPermissions(menuList: Menu[]): Menu[] {
    return menuList.filter(menu => {
      // 如果菜单没有权限要求，则显示
      if (!menu.permission) {
        return true
      }
      
      // 检查是否有权限
      if (!hasPermission(menu.permission)) {
        return false
      }
      
      // 递归过滤子菜单
      if (menu.children && menu.children.length > 0) {
        menu.children = filterMenusByPermissions(menu.children)
      }
      
      return true
    })
  }

  /// <summary>
  /// 获取面包屑导航
  /// </summary>
  function getBreadcrumbs(path: string): Menu[] {
    const breadcrumbs: Menu[] = []
    
    function findPath(menuList: Menu[], targetPath: string, parents: Menu[] = []): boolean {
      for (const menu of menuList) {
        const currentPath = [...parents, menu]
        
        if (menu.path === targetPath) {
          breadcrumbs.push(...currentPath)
          return true
        }
        
        if (menu.children && menu.children.length > 0) {
          if (findPath(menu.children, targetPath, currentPath)) {
            return true
          }
        }
      }
      return false
    }
    
    findPath(menuTree.value, path)
    return breadcrumbs
  }

  /// <summary>
  /// 生成路由
  /// </summary>
  async function generateRoutes(menuList: Menu[] = []) {
    console.log('生成路由，菜单数据:', menuList)
    routes.value = menusToRoutes(menuList)
    isRoutesGenerated.value = true
    
    // 保存路由生成状态
    localStorage.setItem(CACHE_KEY.ROUTES_GENERATED, JSON.stringify(true))
    
    console.log('生成的路由:', routes.value)
    return routes.value
  }

  /// <summary>
  /// 生成默认路由（当没有菜单数据时）
  /// </summary>
  async function generateDefaultRoutes() {
    console.log('生成默认路由')
    
    const defaultMenus: Menu[] = [
      {
        id: '1',
        code: 'dashboard',
        name: '工作台',
        type: 'Menu',
        path: '/dashboard',
        component: 'dashboard/index',
        icon: 'HomeFilled',
        permission: '',
        sortOrder: 1,
        isEnabled: true,
        isVisible: true,
        isKeepAlive: false,
        isExternal: false,
        createdAt: new Date().toISOString()
      }
    ]

    return generateRoutes(defaultMenus)
  }

  /// <summary>
  /// 清空菜单和路由
  /// </summary>
  function clearMenus() {
    menus.value = []
    routes.value = []
    permissions.value = []
    isRoutesGenerated.value = false
    lastUpdateTime.value = 0
    
    // 清除缓存
    clearMenuCache()
    
    console.log('菜单数据已清除')
  }

  /// <summary>
  /// 刷新菜单数据
  /// </summary>
  async function refreshMenus() {
    console.log('手动刷新菜单数据')
    clearMenuCache()
    return await fetchMenuDataFromApi()
  }

  return {
    // 状态
    menus,
    routes,
    permissions,
    loading,
    isRoutesGenerated,
    isInitializing,
    lastUpdateTime,
    
    // 计算属性
    menuTree,
    flatMenus,
    
    // 操作
    fetchUserMenus,
    generateRoutes,
    generateDefaultRoutes,
    hasPermission,
    hasAnyPermission,
    hasAllPermissions,
    findMenuByPath,
    filterMenusByPermissions,
    getBreadcrumbs,
    clearMenus,
    refreshMenus,
    
    // 缓存操作
    saveMenuDataToCache,
    loadMenuDataFromCache,
    clearMenuCache
  }
})