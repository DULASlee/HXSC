// =============================================
// 主题管理服务
// =============================================

// 主题类型
export type ThemeType = 'light' | 'dark' | 'blue'

// 主题配置接口
export interface ThemeConfig {
  name: string
  label: string
  colors: {
    primary: string
    success: string
    warning: string
    danger: string
    info: string
  }
}

// 主题配置
const themeConfigs: Record<ThemeType, ThemeConfig> = {
  light: {
    name: 'light',
    label: '亮色主题',
    colors: {
      primary: '#409eff',
      success: '#67c23a',
      warning: '#e6a23c',
      danger: '#f56c6c',
      info: '#909399'
    }
  },
  dark: {
    name: 'dark',
    label: '暗色主题',
    colors: {
      primary: '#409eff',
      success: '#67c23a',
      warning: '#e6a23c',
      danger: '#f56c6c',
      info: '#909399'
    }
  },
  blue: {
    name: 'blue',
    label: '蓝色主题',
    colors: {
      primary: '#1890ff',
      success: '#52c41a',
      warning: '#faad14',
      danger: '#ff4d4f',
      info: '#909399'
    }
  }
}

// 主题管理服务类
class ThemeService {
  private currentTheme: ThemeType = 'light'
  private readonly storageKey = 'app-theme'
  
  constructor() {
    this.init()
  }
  
  // 初始化主题
  private init() {
    // 从本地存储获取主题
    const savedTheme = localStorage.getItem(this.storageKey) as ThemeType
    
    // 检测系统主题偏好
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches
    
    // 设置初始主题
    const initialTheme = savedTheme || (prefersDark ? 'dark' : 'light')
    this.setTheme(initialTheme)
    
    // 监听系统主题变化
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
      if (!savedTheme) {
        this.setTheme(e.matches ? 'dark' : 'light')
      }
    })
  }
  
  // 获取当前主题
  getCurrentTheme(): ThemeType {
    return this.currentTheme
  }
  
  // 获取主题配置
  getThemeConfig(theme?: ThemeType): ThemeConfig {
    return themeConfigs[theme || this.currentTheme]
  }
  
  // 获取所有主题配置
  getAllThemeConfigs(): Record<ThemeType, ThemeConfig> {
    return themeConfigs
  }
  
  // 设置主题
  setTheme(theme: ThemeType) {
    if (!themeConfigs[theme]) {
      console.warn(`Theme "${theme}" not found, using default theme`)
      theme = 'light'
    }
    
    this.currentTheme = theme
    
    // 设置HTML属性
    document.documentElement.setAttribute('data-theme', theme)
    
    // 设置CSS类名（兼容性）
    document.documentElement.className = document.documentElement.className
      .replace(/theme-\w+/g, '')
      .trim()
    document.documentElement.classList.add(`theme-${theme}`)
    
    // 更新CSS变量
    this.updateCSSVariables(theme)
    
    // 保存到本地存储
    localStorage.setItem(this.storageKey, theme)
    
    // 触发主题变化事件
    this.dispatchThemeChangeEvent(theme)
    
    console.log(`Theme changed to: ${theme}`)
  }
  
  // 更新CSS变量
  private updateCSSVariables(theme: ThemeType) {
    const config = themeConfigs[theme]
    const root = document.documentElement
    
    // 更新主题色变量
    Object.entries(config.colors).forEach(([key, value]) => {
      root.style.setProperty(`--${key}-color`, value)
    })
    
    // 根据主题类型设置特定变量
    switch (theme) {
      case 'dark':
        root.style.setProperty('--text-color-primary', '#e5eaf3')
        root.style.setProperty('--text-color-regular', '#cfd3dc')
        root.style.setProperty('--bg-color', '#141414')
        root.style.setProperty('--bg-color-page', '#0a0a0a')
        break
      case 'blue':
        root.style.setProperty('--primary-color', '#1890ff')
        root.style.setProperty('--bg-color-page', '#f0f5ff')
        break
      default:
        // 亮色主题使用默认值
        break
    }
  }
  
  // 触发主题变化事件
  private dispatchThemeChangeEvent(theme: ThemeType) {
    const event = new CustomEvent('theme-change', {
      detail: { theme, config: themeConfigs[theme] }
    })
    window.dispatchEvent(event)
  }
  
  // 切换主题
  toggleTheme() {
    const themes: ThemeType[] = ['light', 'dark', 'blue']
    const currentIndex = themes.indexOf(this.currentTheme)
    const nextIndex = (currentIndex + 1) % themes.length
    this.setTheme(themes[nextIndex])
  }
  
  // 切换到下一个主题
  nextTheme() {
    this.toggleTheme()
  }
  
  // 是否为暗色主题
  isDarkTheme(): boolean {
    return this.currentTheme === 'dark'
  }
  
  // 是否为亮色主题
  isLightTheme(): boolean {
    return this.currentTheme === 'light'
  }
  
  // 监听主题变化
  onThemeChange(callback: (theme: ThemeType, config: ThemeConfig) => void) {
    const handler = (event: CustomEvent) => {
      callback(event.detail.theme, event.detail.config)
    }
    
    window.addEventListener('theme-change', handler as EventListener)
    
    // 返回取消监听的函数
    return () => {
      window.removeEventListener('theme-change', handler as EventListener)
    }
  }
  
  // 获取主题对应的Element Plus主题
  getElementTheme(): string {
    switch (this.currentTheme) {
      case 'dark':
        return 'dark'
      case 'blue':
        return 'light'
      default:
        return 'light'
    }
  }
  
  // 应用主题到Element Plus
  applyElementTheme() {
    // 这里可以根据需要设置Element Plus的主题变量
    const root = document.documentElement
    const config = this.getThemeConfig()
    
    // 设置Element Plus主题变量
    root.style.setProperty('--el-color-primary', config.colors.primary)
    root.style.setProperty('--el-color-success', config.colors.success)
    root.style.setProperty('--el-color-warning', config.colors.warning)
    root.style.setProperty('--el-color-danger', config.colors.danger)
    root.style.setProperty('--el-color-info', config.colors.info)
  }
  
  // 重置主题
  resetTheme() {
    localStorage.removeItem(this.storageKey)
    this.setTheme('light')
  }
  
  // 导出主题配置
  exportThemeConfig(): string {
    return JSON.stringify({
      currentTheme: this.currentTheme,
      config: this.getThemeConfig()
    }, null, 2)
  }
  
  // 导入主题配置
  importThemeConfig(configJson: string): boolean {
    try {
      const config = JSON.parse(configJson)
      if (config.currentTheme && themeConfigs[config.currentTheme]) {
        this.setTheme(config.currentTheme)
        return true
      }
      return false
    } catch (error) {
      console.error('Failed to import theme config:', error)
      return false
    }
  }
}

// 导出单例实例
export const themeService = new ThemeService()

// 导出默认实例
export default themeService

// 导出主题相关的Vue组合式API
export function useTheme() {
  const getCurrentTheme = () => themeService.getCurrentTheme()
  const setTheme = (theme: ThemeType) => themeService.setTheme(theme)
  const toggleTheme = () => themeService.toggleTheme()
  const isDarkTheme = () => themeService.isDarkTheme()
  const isLightTheme = () => themeService.isLightTheme()
  const getThemeConfig = (theme?: ThemeType) => themeService.getThemeConfig(theme)
  const getAllThemeConfigs = () => themeService.getAllThemeConfigs()
  
  return {
    getCurrentTheme,
    setTheme,
    toggleTheme,
    isDarkTheme,
    isLightTheme,
    getThemeConfig,
    getAllThemeConfigs
  }
}