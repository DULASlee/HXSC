<template>
  <el-menu
    :default-active="activeMenu"
    :collapse="collapse"
    :unique-opened="true"
    :collapse-transition="false"
    mode="vertical"
    class="sidebar-menu"
    @select="handleMenuSelect"
  >
    <template v-for="menu in visibleMenus" :key="menu.path">
      <!-- 只有一个子菜单或没有子菜单的情况 -->
      <el-menu-item 
        v-if="!menu.children || menu.children.length === 0"
        :index="menu.path"
      >
        <el-icon v-if="menu.meta?.icon">
          <component :is="getIconComponent(menu.meta.icon)" />
        </el-icon>
        <template #title>
          <span>{{ menu.meta?.title || menu.name || '未命名菜单' }}</span>
        </template>
      </el-menu-item>
      
      <!-- 有多个子菜单的情况 -->
      <el-sub-menu 
        v-else
        :index="menu.path"
      >
        <template #title>
          <el-icon v-if="menu.meta?.icon">
            <component :is="getIconComponent(menu.meta.icon)" />
          </el-icon>
          <span>{{ menu.meta?.title || menu.name || '未命名菜单' }}</span>
        </template>
        
        <!-- 递归渲染子菜单 -->
        <template v-for="childMenu in menu.children" :key="childMenu.path">
          <el-menu-item 
            v-if="!childMenu.meta?.hidden"
            :index="childMenu.path"
          >
            <el-icon v-if="childMenu.meta?.icon">
              <component :is="getIconComponent(childMenu.meta.icon)" />
            </el-icon>
            <template #title>
              <span>{{ childMenu.meta?.title || childMenu.name || '未命名菜单' }}</span>
            </template>
          </el-menu-item>
        </template>
      </el-sub-menu>
    </template>
  </el-menu>
</template>

<script setup lang="ts">
import { computed } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import type { MenuRoute } from '@/stores/menu';
import * as ElementPlusIconsVue from '@element-plus/icons-vue';

const props = defineProps<{
  menus: MenuRoute[];
  collapse: boolean;
}>();

const route = useRoute();
const router = useRouter();

const activeMenu = computed(() => {
  const { meta, path } = route;
  return meta.activeMenu || path;
});

// 图标组件映射
const getIconComponent = (iconName: string) => {
  if (!iconName) return (ElementPlusIconsVue as any)['Document'];
  
  // 处理不同的图标命名格式
  const iconMap: Record<string, any> = {
    'House': ElementPlusIconsVue.House,
    'HomeFilled': ElementPlusIconsVue.HomeFilled,
    'User': ElementPlusIconsVue.User,
    'UserFilled': ElementPlusIconsVue.UserFilled,
    'Setting': ElementPlusIconsVue.Setting,
    'Document': ElementPlusIconsVue.Document,
    'OfficeBuilding': ElementPlusIconsVue.OfficeBuilding,
    'Monitor': ElementPlusIconsVue.Monitor,
    'Calendar': ElementPlusIconsVue.Calendar,
    'Warning': ElementPlusIconsVue.Warning,
    'Connection': ElementPlusIconsVue.Connection,
    'DataAnalysis': ElementPlusIconsVue.DataAnalysis,
    'List': ElementPlusIconsVue.List,
    'PieChart': ElementPlusIconsVue.PieChart,
    'Upload': ElementPlusIconsVue.Upload,
  };
  
  return iconMap[iconName] || (ElementPlusIconsVue as any)[iconName] || ElementPlusIconsVue.Document;
};

// 菜单选择处理
const handleMenuSelect = (index: string) => {
  if (index && index !== route.path) {
    router.push(index);
  }
};

// 过滤可见菜单
const visibleMenus = computed(() => {
  console.log('SidebarMenu - 原始菜单数据:', props.menus);
  
  const filtered = props.menus.filter(menu => {
    if (!menu || menu.meta?.hidden) return false;
    
    // 如果有子菜单，确保至少有一个可见的子菜单
    if (menu.children && menu.children.length > 0) {
      return menu.children.some(child => !child.meta?.hidden);
    }
    
    return true;
  });
  
  console.log('SidebarMenu - 过滤后的菜单:', filtered);
  return filtered;
});
</script>

<style lang="scss">
.sidebar-menu {
  width: 100%;
  border-right: none !important;
  background-color: var(--sidebar-bg-color) !important;

  .el-menu-item, .el-sub-menu__title {
    color: var(--sidebar-text-color) !important;
    background-color: transparent !important;
    height: 50px;
    line-height: 50px;
    margin: 4px 10px;
    border-radius: 8px;

    .el-icon {
      color: var(--sidebar-text-color);
      margin-right: 12px;
      font-size: 18px;
    }
    
    &:hover {
      background-color: var(--sidebar-hover-bg) !important;
      color: var(--sidebar-hover-text-color) !important;
    }
  }

  .el-menu-item.is-active {
    background-color: var(--el-color-primary) !important;
    color: #fff !important;
  }

  // 子菜单样式
  .el-menu--inline {
    background-color: var(--sidebar-submenu-bg) !important;
    
    .el-menu-item {
      margin: 2px 10px 2px 20px;
      height: 45px;
      line-height: 45px;
      padding-left: 52px !important;
      
      &.is-active {
        background-color: transparent !important;
        color: var(--el-color-primary) !important;
      }

      &::before {
        content: '';
        position: absolute;
        left: 35px;
        top: 50%;
        transform: translateY(-50%);
        width: 5px;
        height: 5px;
        border-radius: 50%;
        background-color: var(--el-color-info-light-3);
      }

       &.is-active::before {
        background-color: var(--el-color-primary);
       }
    }
  }
}
</style>