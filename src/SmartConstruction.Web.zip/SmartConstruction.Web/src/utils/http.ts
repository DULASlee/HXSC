import axios from 'axios'
import type { AxiosInstance, AxiosRequestConfig, AxiosResponse, InternalAxiosRequestConfig } from 'axios'
import { ElMessage } from 'element-plus'
import { useUserStore } from '@/stores/user'
import { getToken, setToken, getRefreshToken, setRefreshToken } from '@/utils/auth'
import router from '@/router'

interface CustomAxiosRequestConfig extends InternalAxiosRequestConfig {
  _isRefreshToken?: boolean;
}

// 全局状态管理
let isRefreshing = false;
let requests: Array<(token: string) => void> = [];

const service: AxiosInstance = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || '',
  timeout: 15000
});

service.interceptors.request.use(
  (config: CustomAxiosRequestConfig) => {
    try {
      const userStateString = localStorage.getItem('user');
      if (userStateString) {
        const userState = JSON.parse(userStateString);
        const token = userState.token;
        const tenantId = userState.currentTenant?.id;

        // 刷新token时不添加Authorization头
        if (token && !config._isRefreshToken) {
          config.headers.Authorization = `Bearer ${token}`;
        }
        
        if (tenantId) {
          config.headers['X-Tenant-Id'] = tenantId;
        }
      }
    } catch (e) {
      console.error('[请求拦截器] localStorage读取错误:', e);
    }
    
    return config;
  },
  (error) => {
    console.error('请求配置错误:', error);
    return Promise.reject(error);
  }
);

service.interceptors.response.use(
  (response: AxiosResponse) => {
    const config = response.config as CustomAxiosRequestConfig;
    const url = config.url || '';

    // 对登录和刷新token的响应，直接返回最原始的 data 部分
    if (config._isRefreshToken || url.includes('/api/auth/login')) {
      return response.data;
    }

    // 直接返回blob响应
    if (response.config.responseType === 'blob') {
      return response;
    }

    // 统一处理业务响应
    const res = response.data;
    const isSuccess = res.success ?? res.isSuccess ?? res.IsSuccess;

    if (isSuccess) {
      // 成功时，返回核心的 data 字段
      return res.data;
    }

    // 业务失败处理
    const errorMessage = res.message || '未知错误';
    const businessError = new Error(`业务错误: ${errorMessage}`);
    Object.assign(businessError, { code: res.code, responseData: res });
    
    // 不再对任何401进行拦截刷新，直接抛出业务错误
    import('@/services/errorService').then(({ errorService }) => {
      errorService.handleError(businessError);
    });
    
    return Promise.reject(businessError);
  },
  (error) => {
    // 不再对任何401进行拦截刷新，直接抛出网络错误
    const { config, response } = error;
    const errorMessage = `网络错误: ${error.message}`;
    const networkError = new Error(errorMessage);
    Object.assign(networkError, { originalError: error });

    import('@/services/errorService').then(({ errorService }) => {
      errorService.handleError(networkError);
    });
    
    return Promise.reject(networkError);
  }
);

/** 统一处理401未授权错误 */
function handleUnauthorized(config: CustomAxiosRequestConfig): Promise<any> {
  if (!isRefreshing) {
    isRefreshing = true;
    return refreshToken()
      .then(token => {
        // 更新原请求头并重新发送
        config.headers.Authorization = `Bearer ${token}`;
        // 将队列中的请求也一并发送
        requests.forEach(cb => cb(token));
        requests = [];
        return service(config);
      })
      .catch((err) => {
        console.error('刷新令牌失败，将登出:', err);
        (useUserStore() as any).logout();
        return Promise.reject(err);
      })
      .finally(() => {
        isRefreshing = false;
      });
  }

  // 若正在刷新，则将请求加入队列
  return new Promise((resolve) => {
    requests.push((token) => {
      config.headers.Authorization = `Bearer ${token}`;
      resolve(service(config));
    });
  });
}

/** 刷新Token逻辑 */
async function refreshToken(): Promise<string> {
  try {
    const token = getRefreshToken();
    if (!token) throw new Error('刷新令牌不可用');

    const res = await service.post('/auth/refresh-token', { refreshToken: token }, {
      _isRefreshToken: true
    } as CustomAxiosRequestConfig) as { accessToken: string; refreshToken: string };

    const { accessToken, refreshToken: newRefreshToken } = res;
    setToken(accessToken);
    setRefreshToken(newRefreshToken);
    
    return accessToken;
  } catch (error) {
    // 明确地在catch中再次抛出错误，以便handleUnauthorized能捕获到
    throw error;
  }
}

// 封装HTTP方法
export const http = {
  get: <T>(url: string, params?: any, config?: AxiosRequestConfig) => 
    service.get<T, T>(url, { params, ...config }),

  post: <T>(url: string, data?: any, config?: AxiosRequestConfig) => 
    service.post<T, T>(url, data, config),

  put: <T>(url: string, data?: any, config?: AxiosRequestConfig) => 
    service.put<T, T>(url, data, config),

  delete: <T>(url: string, params?: any, config?: AxiosRequestConfig) => 
    service.delete<T, T>(url, { params, ...config })
};

export default service;