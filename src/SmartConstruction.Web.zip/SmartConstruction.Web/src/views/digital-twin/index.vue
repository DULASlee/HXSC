<template>
  <DigitalTwinLayout
    :project-name="currentProject.name"
    :tabs="digitalTwinTabs"
    :active-tab="activeTab"
    @tab-change="handleTabChange"
    @return-home="handleReturnHome"
  >
    <component :is="currentScreenComponent" />
  </DigitalTwinLayout>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'

import DigitalTwinLayout from './layout/DigitalTwinLayout.vue'
import CommandCenter from './screens/CommandCenter.vue'
import AttendanceScreen from './screens/AttendanceScreen.vue'
import VideoMonitor from './screens/VideoMonitor.vue'
import CraneManagement from './screens/CraneManagement.vue'
import EnvironmentMonitor from './screens/EnvironmentMonitor.vue'

const route = useRoute()
const router = useRouter()

// 数字孪生标签页配置
const digitalTwinTabs = [
  {
    key: 'command-center',
    label: '指挥中心',
    component: 'CommandCenter'
  },
  {
    key: 'attendance',
    label: '项目考勤',
    component: 'AttendanceScreen'
  },
  {
    key: 'video-monitor',
    label: '视频监控',
    component: 'VideoMonitor'
  },
  {
    key: 'crane-management',
    label: '塔吊升降机管理',
    component: 'CraneManagement'
  },
  {
    key: 'environment-monitor',
    label: '扬尘噪音监测',
    component: 'EnvironmentMonitor'
  }
]

// 当前项目信息
const currentProject = ref({
  id: 'proj001',
  name: '智慧工地示范项目A区'
})

// 当前激活的标签页
const activeTab = ref(route.query.tab as string || 'command-center')

// 当前屏幕组件
const currentScreenComponent = computed(() => {
  const tab = digitalTwinTabs.find(t => t.key === activeTab.value)
  if (!tab) return CommandCenter
  
  switch (tab.component) {
    case 'CommandCenter':
      return CommandCenter
    case 'AttendanceScreen':
      return AttendanceScreen
    case 'VideoMonitor':
      return VideoMonitor
    case 'CraneManagement':
      return CraneManagement
    case 'EnvironmentMonitor':
      return EnvironmentMonitor
    default:
      return CommandCenter
  }
})

// 处理标签页切换
const handleTabChange = (tabKey: string) => {
  activeTab.value = tabKey
  
  // 更新路由查询参数
  router.push({
    name: route.name,
    query: {
      ...route.query,
      tab: tabKey
    }
  })
}

// 处理返回主页
const handleReturnHome = () => {
  router.push('/')
}

// 根据项目ID获取项目信息
const getProjectInfo = async (projectId?: string) => {
  if (projectId) {
    // 这里可以调用API获取具体项目信息
    try {
      // const response = await digitalTwinService.getProjectInfo(projectId)
      // currentProject.value = response.data
    } catch (error) {
      console.error('Failed to load project info:', error)
    }
  }
}

onMounted(() => {
  // 如果路由中有项目ID，获取项目信息
  const projectId = route.query.projectId as string
  if (projectId) {
    getProjectInfo(projectId)
  }
})
</script>

<style lang="scss" scoped>
// 样式由DigitalTwinLayout组件提供
</style>