<template>
  <placeholder-view />
</template>

<script setup lang="ts">
import PlaceholderView from '@/components/PlaceholderView.vue'
</script>