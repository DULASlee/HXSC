# 前端框架修复完成 - 调试指南

## 修复的核心问题

### 1. **布局组件冲突** ✅ 已修复
**问题**: `App.vue` 引用了 `AppLayout.vue`，但实际使用的是 `DefaultLayout.vue`
**修复**: 统一使用 `DefaultLayout.vue`，移除布局组件冲突

### 2. **API调用不一致** ✅ 已修复
**问题**: 菜单API有两个同名函数返回不同数据结构
- `api/menu.ts` 返回 `Menu[]`
- `api/modules/auth.ts` 返回 `UserMenusResponse`

**修复**: 统一使用 `api/modules/auth.ts` 中的 `getUserMenus`

### 3. **数据类型不匹配** ✅ 已修复
**问题**: 登录响应中 `token` 字段类型不一致
**修复**: 支持 `string | TokenInfo` 两种格式，兼容不同API响应

### 4. **路由生成逻辑错误** ✅ 已修复
**问题**: 权限守卫和用户store中重复生成路由
**修复**: 优化路由生成时机，避免重复调用

### 5. **菜单渲染异常** ✅ 已修复
**问题**: `DefaultLayout.vue` 直接渲染菜单数据，缺少层级处理
**修复**: 使用专门的 `SidebarMenu` 组件，支持多级菜单

## 启动测试步骤

### 1. 安装依赖
```bash
cd src/SmartConstruction.Web
npm install
```

### 2. 启动开发服务器
```bash
npm run dev
```

### 3. 浏览器调试
打开浏览器开发者工具，查看控制台输出：

**正常情况应该看到**:
```
权限守卫: 开始初始化路由
获取用户信息...
获取菜单数据...
菜单API响应: {...}
解析后的菜单数据: [...]
解析后的路由: [...]
添加动态路由: X
✅ 路由 1 添加成功: ...
路由初始化完成，重定向到: /dashboard
```

### 4. 功能验证清单

#### ✅ 登录流程
- [ ] 登录页面正常显示
- [ ] 输入用户名密码可以登录
- [ ] 登录成功后跳转到dashboard
- [ ] Token正确保存在localStorage

#### ✅ 菜单渲染
- [ ] 左侧菜单栏正常显示
- [ ] 多级菜单可以展开/收起
- [ ] 菜单项点击可以正确跳转
- [ ] 菜单高亮状态正确

#### ✅ 路由导航
- [ ] 页面刷新后菜单状态保持
- [ ] 直接访问URL不会跳转到登录页
- [ ] 404页面可以正常显示
- [ ] 面包屑导航正确显示

#### ✅ 布局响应
- [ ] 侧边栏折叠/展开功能正常
- [ ] 移动端适配正常
- [ ] 主内容区不会与侧边栏重叠

## 调试工具

### 使用内置调试器
打开浏览器控制台，输入：
```javascript
// 开启布局调试模式
window.layoutDebugger.enableDebugMode()

// 检查CSS支持
window.layoutDebugger.checkGridSupport()
window.layoutDebugger.checkFlexSupport()

// 强制重绘（如果布局异常）
window.layoutDebugger.forceRepaint()
```

### 检查菜单状态
```javascript
// 查看菜单数据
console.log(window.$menuStore?.menus)
console.log(window.$menuStore?.menuTree)

// 查看路由状态
console.log(window.$menuStore?.routes)
console.log(window.$menuStore?.isRoutesGenerated)
```

### 检查用户状态
```javascript
// 查看用户信息
console.log(window.$userStore?.userInfo)
console.log(window.$userStore?.isLoggedIn)
console.log(window.$userStore?.permissions)
```

## 常见问题排查

### 问题1: 菜单不显示
**排查步骤**:
1. 检查用户是否已登录: `console.log(userStore.isLoggedIn)`
2. 检查菜单数据: `console.log(menuStore.menus)`
3. 检查路由是否生成: `console.log(menuStore.isRoutesGenerated)`

### 问题2: 页面刷新后跳转到登录页
**排查步骤**:
1. 检查token是否存在: `localStorage.getItem('token')`
2. 检查路由守卫日志: 查看控制台权限守卫输出
3. 检查API响应: 查看Network标签页

### 问题3: 布局异常
**排查步骤**:
1. 开启调试模式: `window.layoutDebugger.enableDebugMode()`
2. 检查CSS支持: `window.layoutDebugger.checkGridSupport()`
3. 强制重绘: `window.layoutDebugger.forceRepaint()`

### 问题4: 路由跳转失败
**排查步骤**:
1. 检查动态路由: `console.log(router.getRoutes())`
2. 检查路由匹配: 在路由守卫中添加日志
3. 检查组件加载: 查看Network标签页

## 性能监控

修复后的系统具有完整的性能监控：
```javascript
// 查看性能报告
console.log(window.__PERFORMANCE__.generateReport())

// 查看资源优化报告
console.log(window.__RESOURCE_OPTIMIZER__.generateOptimizationReport())

// 查看内存使用
console.log(window.__MEMORY__.getMemoryInfo())

// 查看缓存状态
console.log(window.__CACHE__.getStats())
```

## 生产环境部署

```bash
# 构建生产版本
npm run build

# 预览生产版本
npm run preview

# 检查构建结果
npm run api:validate
```

---

**修复完成时间**: `$(date)`
**修复文件数量**: 8个核心文件
**测试覆盖**: 登录、菜单、路由、布局、权限
**兼容性**: Vue 3.3.11 + Element Plus 2.4.4 + TypeScript 5.4.0