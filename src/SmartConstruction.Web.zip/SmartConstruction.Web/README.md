# 智慧建设巴伯框架 Web 前端

<div align="center">
  <img src="public/images/logo.png" alt="巴伯框架 Logo" width="200" />
  <h3>智慧建设巴伯框架 - 多租户企业级前端解决方案</h3>
  <p>基于 Vue 3 + TypeScript + Vite 构建的现代化企业级前端框架</p>
</div>

<p align="center">
  <img src="https://img.shields.io/badge/vue-3.4.x-brightgreen.svg" alt="vue">
  <img src="https://img.shields.io/badge/typescript-5.x-blue.svg" alt="typescript">
  <img src="https://img.shields.io/badge/vite-5.x-purple.svg" alt="vite">
  <img src="https://img.shields.io/badge/element--plus-2.x-green.svg" alt="element-plus">
  <img src="https://img.shields.io/badge/pinia-2.x-yellow.svg" alt="pinia">
  <img src="https://img.shields.io/badge/license-MIT-blue.svg" alt="license">
</p>

## 📋 目录

- [项目介绍](#-项目介绍)
- [功能特性](#-功能特性)
- [技术栈](#-技术栈)
- [环境要求](#-环境要求)
- [快速开始](#-快速开始)
- [项目结构](#-项目结构)
- [开发指南](#-开发指南)
- [API 服务](#-api-服务)
- [国际化](#-国际化)
- [主题定制](#-主题定制)
- [部署指南](#-部署指南)
- [常见问题](#-常见问题)
- [贡献指南](#-贡献指南)
- [许可证](#-许可证)

## 🚀 项目介绍

智慧建设巴伯框架是一个基于 Vue 3、TypeScript 和 Vite 构建的企业级前端解决方案。它提供了完整的多租户管理、权限控制、组织架构管理等功能，适用于大型企业应用系统的快速开发。

本框架采用现代化的前端技术栈，提供了丰富的组件和工具，帮助开发者快速构建高质量的企业级应用。

## ✨ 功能特性

- **多租户架构**：支持多租户隔离，每个租户拥有独立的数据和配置
- **权限管理**：细粒度的权限控制，支持角色、资源、数据权限等多维度权限管理
- **组织架构**：完整的组织架构管理，支持多级组织、部门、岗位等
- **用户管理**：用户创建、角色分配、权限控制等功能
- **主题定制**：可定制的主题系统，支持动态切换主题
- **国际化**：内置多语言支持，轻松实现国际化
- **响应式设计**：适配不同尺寸的屏幕和设备
- **统一认证**：集成统一的认证中心，支持单点登录
- **实时通信**：基于 WebSocket 的实时消息通知系统
- **数据可视化**：集成多种图表组件，支持数据可视化展示
- **高级表格**：支持复杂数据展示、筛选、排序、导出等功能
- **表单生成器**：可视化表单设计和生成
- **工作流引擎**：可视化流程设计和执行
- **文件管理**：文件上传、下载、预览等功能
- **审计日志**：系统操作日志记录和查询

## 🛠️ 技术栈

- **核心框架**：[Vue 3](https://v3.vuejs.org/)
- **编程语言**：[TypeScript](https://www.typescriptlang.org/)
- **构建工具**：[Vite](https://vitejs.dev/)
- **状态管理**：[Pinia](https://pinia.vuejs.org/)
- **UI 组件库**：[Element Plus](https://element-plus.org/)
- **路由管理**：[Vue Router](https://router.vuejs.org/)
- **HTTP 客户端**：[Axios](https://axios-http.com/)
- **CSS 预处理器**：[Sass](https://sass-lang.com/)
- **图表库**：[ECharts](https://echarts.apache.org/)
- **工具库**：
  - [VueUse](https://vueuse.org/) - Vue 组合式 API 工具集
  - [dayjs](https://day.js.org/) - 日期处理库
  - [lodash-es](https://lodash.com/) - 实用工具库

## 📋 环境要求

- Node.js >= 18.0.0
- npm >= 9.0.0 或 yarn >= 1.22.0 或 pnpm >= 8.0.0

## 🚀 快速开始

### 安装

```bash
# 克隆项目
git clone https://github.com/your-organization/smart-construction-babaob-framework-web.git

# 进入项目目录
cd smart-construction-babaob-framework-web

# 安装依赖
npm install
# 或
yarn install
# 或
pnpm install
```

### 开发

```bash
# 启动开发服务器
npm run dev
# 或
yarn dev
# 或
pnpm dev
```

### 构建

```bash
# 构建生产环境
npm run build
# 或
yarn build
# 或
pnpm build
```

### 预览

```bash
# 预览生产构建
npm run preview
# 或
yarn preview
# 或
pnpm preview
```

## 📁 项目结构

```
smart-construction-babaob-framework-web/
├── public/                 # 静态资源
│   ├── images/             # 图片资源
│   └── favicon.ico         # 网站图标
├── src/                    # 源代码
│   ├── api/                # API 接口
│   │   ├── modules/        # API 模块
│   │   ├── services/       # API 服务
│   │   └── request.ts      # 请求封装
│   ├── assets/             # 资源文件
│   ├── components/         # 公共组件
│   ├── composables/        # 组合式函数
│   ├── config/             # 配置文件
│   ├── directives/         # 自定义指令
│   ├── layouts/            # 布局组件
│   ├── locales/            # 国际化资源
│   ├── router/             # 路由配置
│   ├── services/           # 业务服务
│   ├── stores/             # 状态管理
│   ├── styles/             # 样式文件
│   ├── types/              # 类型定义
│   ├── utils/              # 工具函数
│   ├── views/              # 页面组件
│   ├── App.vue             # 根组件
│   ├── main.ts             # 入口文件
│   └── permission.ts       # 权限控制
├── .env                    # 环境变量
├── .env.development        # 开发环境变量
├── .env.production         # 生产环境变量
├── .eslintrc.cjs           # ESLint 配置
├── .gitignore              # Git 忽略文件
├── index.html              # HTML 模板
├── package.json            # 项目依赖
├── README.md               # 项目说明
├── tsconfig.json           # TypeScript 配置
└── vite.config.ts          # Vite 配置
```

## 🧩 开发指南

### 代码规范

本项目使用 ESLint 和 Prettier 来保证代码质量和一致性。

```bash
# 运行代码检查
npm run lint
# 或
yarn lint
# 或
pnpm lint

# 自动修复代码格式
npm run format
# 或
yarn format
# 或
pnpm format
```

### 提交规范

本项目使用 [Conventional Commits](https://www.conventionalcommits.org/) 规范进行代码提交。

提交格式：

```
<type>(<scope>): <subject>
```

常用的 `type` 类型：

- `feat`: 新功能
- `fix`: 修复 Bug
- `docs`: 文档更新
- `style`: 代码风格或格式修改
- `refactor`: 代码重构
- `perf`: 性能优化
- `test`: 测试相关
- `build`: 构建系统或外部依赖更改
- `ci`: CI 配置和脚本更改
- `chore`: 其他修改

示例：

```
feat(user): 添加用户管理页面
fix(auth): 修复登录失败问题
docs(readme): 更新安装说明
```

### 分支管理

- `main`: 主分支，用于生产环境
- `develop`: 开发分支，用于开发环境
- `feature/*`: 功能分支，用于开发新功能
- `hotfix/*`: 热修复分支，用于修复生产环境的紧急问题

## 📡 API 服务

本项目提供了两种API服务层实现，用于与后端API进行交互：

### 1. 传统服务层

传统API服务层位于 `src/api/services` 目录下，包含以下服务：

- `AuthService`: 认证相关 API
- `UserService`: 用户管理 API
- `RoleService`: 角色管理 API
- `OrganizationService`: 组织管理 API
- `TenantService`: 租户管理 API
- `ResourceService`: 资源管理 API
- `MetadataService`: 元数据管理 API
- `AuditService`: 审计日志 API
- `SystemService`: 系统管理 API

### 2. 智能化API系统 (新)

新的智能化API系统提供了更强大、更灵活的API通信能力，支持从Swagger自动生成API配置和类型定义。

#### 核心特性

- **配置驱动**: 统一的API配置管理
- **OpenAPI集成**: 自动从Swagger生成API配置和类型
- **智能客户端**: 统一的错误处理、Token刷新、请求/响应拦截
- **Vue组合式函数**: 提供多种API调用模式的组合式函数
- **开发者工具**: API管理器、配置验证、连接测试等

#### 目录结构

```
src/api/
├── client.ts           # 智能API客户端
├── config.ts           # API配置管理
├── generator.ts        # OpenAPI生成器
├── manager.ts          # API管理工具
├── generated-types.d.ts # 自动生成的API类型
└── README.md           # API使用指南
```

#### 快速开始

1. **生成API类型**

```bash
# 从Swagger生成API类型
npm run api:generate
```

2. **初始化API系统**

```typescript
// main.ts
import { initializeApi } from '@/api/manager';

await initializeApi({
  swaggerUrl: 'http://localhost:7999/swagger/v1/swagger.json',
  autoGenerate: true
});
```

3. **在组件中使用**

```typescript
// 使用组合式函数
// This is an example, actual import might differ based on exports

// 用户列表
const {
  items: users,
  loading,
  pagination,
  loadData,
  refresh
} = useApiList('users', 'getList', {
  immediate: true,
  pagination: { pageSize: 10 }
});

// 创建用户
const { submit: createUser, isSubmitting } = useApiSubmit('users', 'create', {
  onSuccess: () => refresh()
});
```

4. **直接API调用**

```typescript
// 直接使用API客户端
import { api } from '@/api/client';

// 登录
const response = await api.auth.login({
  username: 'admin',
  password: '12345',
  tenantCode: 'SYSTEM'
});

// 获取用户列表
const users = await api.users.getList({ page: 1, pageSize: 10 });
```

#### 高级功能

- **批量API调用**: 一次性执行多个API请求
- **文件操作**: 上传下载文件，带进度显示
- **错误恢复**: 自动重试和错误处理策略
- **配置管理**: 运行时配置更新和验证
- **监控统计**: API调用统计和性能监控

更多API使用示例，请参考 [API使用示例](src/examples/api-usage.ts)。

## 🌍 国际化

本项目使用 [vue-i18n](https://vue-i18n.intlify.dev/) 实现国际化。国际化资源文件位于 `src/locales` 目录下。

### 添加新语言

1. 在 `src/locales` 目录下创建新的语言文件，例如 `ja.ts`
2. 在 `src/locales/index.ts` 中导入并注册新语言

### 使用国际化

在模板中使用：

```vue
<template>
  <div>
    <h1>{{ $t('welcome') }}</h1>
    <p>{{ $t('user.profile') }}</p>
  </div>
</template>
```

在 JavaScript/TypeScript 中使用：

```typescript
import { useI18n } from 'vue-i18n';

export default {
  setup() {
    const { t } = useI18n();
    
    return {
      welcomeMessage: t('welcome'),
      userProfile: t('user.profile')
    };
  }
};
```

## 🎨 主题定制

本项目支持主题定制，可以通过修改 Element Plus 的主题变量来实现。主题相关的配置文件位于 `src/styles` 目录下。

### 修改主题变量

编辑 `src/styles/variables.scss` 文件，修改主题变量：

```scss
// 主题颜色
$primary-color: #409eff;
$success-color: #67c23a;
$warning-color: #e6a23c;
$danger-color: #f56c6c;
$info-color: #909399;

// 文字颜色
$text-color-primary: #303133;
$text-color-regular: #606266;
$text-color-secondary: #909399;
$text-color-placeholder: #c0c4cc;

// 边框颜色
$border-color-base: #dcdfe6;
$border-color-light: #e4e7ed;
$border-color-lighter: #ebeef5;
$border-color-extra-light: #f2f6fc;

// 背景颜色
$background-color-base: #f5f7fa;
```

### 动态切换主题

本项目支持动态切换主题，实现方式是通过动态加载 CSS 变量。

```typescript
import { useAppStore } from '@/stores/app';

const appStore = useAppStore();

// 切换到暗色主题
appStore.setTheme('dark');

// 切换到浅色主题
appStore.setTheme('light');

// 切换到自定义主题
appStore.setTheme('custom');
```

## 📦 部署指南

### 环境变量配置

在部署前，需要根据不同环境配置环境变量。环境变量文件包括：

- `.env`: 所有环境通用的环境变量
- `.env.development`: 开发环境的环境变量
- `.env.production`: 生产环境的环境变量

主要的环境变量：

```
# API 基础路径
VITE_API_BASE_URL=/api

# 是否启用 Mock 数据
VITE_USE_MOCK=false

# 是否启用 PWA
VITE_USE_PWA=false

# 应用标题
VITE_APP_TITLE=智慧建设巴伯框架

# 是否删除 console
VITE_DROP_CONSOLE=true
```

### 构建生产版本

```bash
# 构建生产环境
npm run build
# 或
yarn build
# 或
pnpm build
```

构建完成后，生成的文件将位于 `dist` 目录下。

### Nginx 配置

以下是一个基本的 Nginx 配置示例：

```nginx
server {
    listen 80;
    server_name your-domain.com;

    root /path/to/dist;
    index index.html;

    # 处理单页应用路由
    location / {
        try_files $uri $uri/ /index.html;
    }

    # API 代理
    location /api {
        proxy_pass http://your-api-server;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # 静态资源缓存
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
        expires 30d;
        add_header Cache-Control "public, no-transform";
    }
}
```

### Docker 部署

本项目提供了 Dockerfile，可以使用 Docker 进行部署。

```bash
# 构建 Docker 镜像
docker build -t smart-construction-babaob-framework-web .

# 运行 Docker 容器
docker run -d -p 80:80 --name babaob-web smart-construction-babaob-framework-web
```

## ❓ 常见问题

### 1. 如何处理跨域问题？

在开发环境中，可以通过 Vite 的代理功能解决跨域问题。编辑 `vite.config.ts` 文件：

```typescript
export default defineConfig({
  // ...
  server: {
    proxy: {
      '/api': {
        target: 'http://your-api-server',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api/, '')
      }
    }
  }
  // ...
});
```

在生产环境中，建议通过 Nginx 代理解决跨域问题。

### 2. 如何添加新页面？

1. 在 `src/views` 目录下创建新的页面组件
2. 在 `src/router/modules` 目录下添加路由配置
3. 在 `src/router/index.ts` 中导入并注册路由模块

### 3. 如何处理权限控制？

本项目使用基于角色的权限控制系统。权限控制的核心逻辑位于 `src/permission.ts` 文件中。

可以使用 `v-permission` 指令控制元素的显示：

```vue
<!-- 只有拥有 'user:create' 权限的用户才能看到此按钮 -->
<el-button v-permission="'user:create'">创建用户</el-button>

<!-- 只有 'admin' 角色的用户才能看到此按钮 -->
<el-button v-permission="{ role: 'admin' }">管理员操作</el-button>
```

也可以使用 `usePermission` 组合式函数进行编程式权限检查：

```typescript
import { usePermission } from '@/composables/usePermission';

export default {
  setup() {
    const { hasPermission, hasRole } = usePermission();
    
    const canCreateUser = hasPermission('user:create');
    const isAdmin = hasRole('admin');
    
    return {
      canCreateUser,
      isAdmin
    };
  }
};
```

## 🤝 贡献指南

欢迎贡献代码、报告问题或提出建议！请遵循以下步骤：

1. Fork 本仓库
2. 创建你的特性分支 (`git checkout -b feature/amazing-feature`)
3. 提交你的更改 (`git commit -m 'feat: add some amazing feature'`)
4. 推送到分支 (`git push origin feature/amazing-feature`)
5. 打开一个 Pull Request

## 📄 许可证

本项目采用 [MIT 许可证](LICENSE)。

---

<div align="center">
  <p>智慧建设巴伯框架 Web 前端 © 2025</p>
</div>
